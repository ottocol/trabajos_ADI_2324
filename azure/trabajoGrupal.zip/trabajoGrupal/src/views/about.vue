<template>
  <div class="content-container">
    <div class="content-title-group not-found">
      <h2 class="title">Trabajos en grupo</h2>
      <p>
        Proyecto para la asignatura de aplicaciones distribuidas en internet
      </p>
      <br />
      <h2 class="title">Integrantes</h2>
      <ul>
        <li>
          <div class="text">Adam Roy Frederick William Reading</div>
        </li>
        <li>
          <div class="text">Emilio Prieto Uclés</div>
        </li>
        <li>
          <div class="text">Pablo Jimenez Fernandez</div>
        </li>
      </ul>
    </div>
  </div>
</template>
