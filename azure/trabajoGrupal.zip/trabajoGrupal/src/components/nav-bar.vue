<template>
  <nav class="column is-2 menu">
    <p class="menu-label">Menu</p>
    <ul class="menu-list">
      <router-link to="/products">Products</router-link>
      <router-link to="/about">About</router-link>
    </ul>
  </nav>
</template>
