import { Component } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { OPCIONES } from '../tablero/tablero.component';
import { JugadoresService } from '../jugadores.service';
import { AudioService } from '../audio.service';

@Component({
  selector: 'app-ganador',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './ganador.component.html',
  styleUrl: './ganador.component.css'
})
export class GanadorComponent {
  fichaGanadora!: OPCIONES;
  nombreGanador!: string;
  constructor(private activatedRoute: ActivatedRoute, private jugadoresService: JugadoresService, private audioService: AudioService) { }

  ngOnInit() {
    this.activatedRoute.queryParams.subscribe(params => {
      this.fichaGanadora = params['ficha'];
      this.nombreGanador = this.jugadoresService.getNombreByFicha(this.fichaGanadora);
    })
  }

  ngAfterViewInit() {
    this.audioService.playGanador();
  }
}
