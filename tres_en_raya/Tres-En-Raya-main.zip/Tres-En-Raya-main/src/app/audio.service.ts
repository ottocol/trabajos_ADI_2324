import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AudioService {
  private audioGanador = new Audio();
  private audioFicha = new Audio();
  private audioEmpate = new Audio();

  constructor() {
    this.audioGanador.src = 'assets/audios/ganador.mp3';
    this.audioFicha.src = 'assets/audios/ficha.mp3';
    this.audioEmpate.src = 'assets/audios/empate.mp3';
  }

  playGanador(): void {
    this.audioGanador.play();
  }

  playFicha(): void {
    this.audioFicha.play();
  }

  playEmpate(): void {
    this.audioEmpate.play();
  }
}
