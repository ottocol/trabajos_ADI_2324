import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ElegirFichaComponent } from './elegir-ficha.component';

describe('ElegirFichaComponent', () => {
  let component: ElegirFichaComponent;
  let fixture: ComponentFixture<ElegirFichaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ElegirFichaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ElegirFichaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
