import { Component } from '@angular/core';
import { PartidaService } from '../partida.service';
import { OPCIONES } from '../tablero/tablero.component';
import { Router } from '@angular/router';
import { JugadoresService } from '../jugadores.service';
import { FormBuilder, Validators, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { NgClass } from '@angular/common';

@Component({
  selector: 'app-elegir-ficha',
  standalone: true,
  imports: [ReactiveFormsModule, NgClass],
  templateUrl: './elegir-ficha.component.html',
  styleUrl: './elegir-ficha.component.css'
})
export class ElegirFichaComponent {
  selectedFicha: string = '';
  form: FormGroup;
  constructor(private fb: FormBuilder, private partidaService: PartidaService, private jugadoresService: JugadoresService, private router: Router) {
    this.form = this.fb.group({
      jugadorX: ['', Validators.required],
      jugadorO: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.form.patchValue({
      jugadorX: this.jugadoresService.getNombreByFicha(OPCIONES.X) || '',
      jugadorO: this.jugadoresService.getNombreByFicha(OPCIONES.O) || ''
    });
  }

  getPartidaService(): PartidaService {
    return this.partidaService;
  }

  onClick(eleccion: string): void {
    this.selectedFicha = eleccion;
    switch (eleccion) {
      case 'x': this.partidaService.setFichaActual(OPCIONES.X); break;
      case 'o': this.partidaService.setFichaActual(OPCIONES.O); break;
    }
  }

  onSubmit(): void {
    if (this.form.valid) {
      this.jugadoresService.guardarJugadores(this.form.value.jugadorX, this.form.value.jugadorO);
      this.router.navigate(['/partida']);
    } else {
      alert('Por favor, introduce los nombres de ambos jugadores');
    }
  }

}
