import { Injectable } from '@angular/core';
import { OPCIONES, TableroComponent } from './tablero/tablero.component';
import { JugadoresService } from './jugadores.service';
import { Router } from '@angular/router';
import { AudioService } from './audio.service';

export const COMBINACION_GANADORA = [
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 4, 8],
  [2, 4, 6]
] as const

@Injectable({
  providedIn: 'root'
})
export class PartidaService {
  private fichaActual: OPCIONES;
  private turno: number;
  private empate: boolean = false;

  constructor(private jugadoresService: JugadoresService, private router: Router, private audioService: AudioService) {
    this.turno = 1;
    this.fichaActual = this.turno === 1 ? OPCIONES.X : OPCIONES.O;
  }

  public getFichaActual(): OPCIONES {
    let ficha: OPCIONES = this.fichaActual;
    this.fichaActual = this.turno === 1 ? OPCIONES.X : OPCIONES.O;
    return ficha;
  }

  public setFichaActual(fichaElegida: OPCIONES): void {
    this.fichaActual = fichaElegida;
    this.turno = fichaElegida === OPCIONES.X ? 1 : 2;
  }

  public verificarGanador(board: TableroComponent): void {
    for (let i = 0; COMBINACION_GANADORA.length > i; i++) {
      const [a, b, c] = COMBINACION_GANADORA[i]
      if (board.get(a) !== OPCIONES.NADA && board.get(a) === board.get(b) && board.get(c) === board.get(b)) {
        this.router.navigate(['/ganador'], { queryParams: { ficha: board.get(a) } });
      }
    }
    this.verificarEmpate(board);
  }

  public verificarEmpate(board: TableroComponent): void {
    let lleno: boolean = true;
    for (let i = 0; 9 > i; i++) {
      if (lleno && board.get(i) === OPCIONES.NADA) lleno = false;
    }
    if (lleno) {
      this.empate = true;
      this.audioService.playEmpate();
    }
  }

  public getTurno(): number {
    return this.turno;
  }

  public cambioTurno(): void {
    this.turno === 1 ? this.turno = 2 : this.turno = 1;
    this.jugadoresService.getNombreByFicha(this.getFichaActual());
  }

  public getEmpate(): boolean {
    return this.empate;
  }
}
