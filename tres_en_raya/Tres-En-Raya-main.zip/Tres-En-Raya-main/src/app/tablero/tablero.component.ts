import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { CasillaComponent } from './casilla/casilla.component';
import { PartidaService } from '../partida.service';
import { JugadoresService } from '../jugadores.service';
import { RouterLink } from '@angular/router';

export enum OPCIONES {
  X = 'X',
  O = 'O',
  NADA = ''
}

@Component({
  selector: 'app-tablero',
  standalone: true,
  imports: [CommonModule, CasillaComponent, RouterLink],
  templateUrl: './tablero.component.html',
  styleUrl: './tablero.component.css'
})
export class TableroComponent {
  casillas: OPCIONES[] = new Array(9);
  proximaFicha: OPCIONES = this.partidaService.getFichaActual();
  empate: boolean = this.partidaService.getEmpate();

  constructor(private partidaService: PartidaService, private jugadoresService: JugadoresService) {
    this.inicializarTablero();
  }

  private inicializarTablero(): void {
    this.casillas.fill(OPCIONES.NADA);
  }

  public get(casilla: number): OPCIONES {
    return this.casillas[casilla];
  }

  public set(casilla: number, jugador: OPCIONES): void {
    this.casillas[casilla] = jugador;
    this.partidaService.verificarGanador(this);
  }

  public getTurno(): string {
    return `jugador 
            ${this.jugadoresService.getNombreByFicha(this.partidaService.getFichaActual()) ?? ''} 
            (${this.partidaService.getFichaActual().toString()})`;
  }

  onSeleccionCasilla(index: number): void {
    this.set(index, this.partidaService.getFichaActual());
    this.partidaService.cambioTurno();
    this.proximaFicha = this.partidaService.getFichaActual();
    this.empate = this.partidaService.getEmpate();
  }
}
