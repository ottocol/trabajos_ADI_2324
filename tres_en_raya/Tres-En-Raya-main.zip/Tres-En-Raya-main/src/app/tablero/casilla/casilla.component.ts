import { Component, EventEmitter, Input, Output } from '@angular/core';
import { OPCIONES } from '../tablero.component';
import { CommonModule } from '@angular/common';
import { AudioService } from '../../audio.service';

@Component({
  selector: 'app-casilla',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './casilla.component.html',
  styleUrl: './casilla.component.css'
})
export class CasillaComponent {
  public opcionesEnum = OPCIONES;
  @Input() opcion!: OPCIONES;
  @Input() proximaFicha!: OPCIONES;
  @Output() seleccionCasilla = new EventEmitter<void>();

  constructor(private audioService: AudioService) { }

  onClick() {
    if (this.opcion === this.opcionesEnum.NADA) {
      this.seleccionCasilla.emit();
      this.audioService.playFicha();
    }
  }
}
