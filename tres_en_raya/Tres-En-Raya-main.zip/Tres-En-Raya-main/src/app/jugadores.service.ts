import { Injectable } from '@angular/core';
import { OPCIONES } from './tablero/tablero.component';

@Injectable({
  providedIn: 'root'
})
export class JugadoresService {
  private jugadorX!: string;
  private jugadorO!: string;

  constructor() { }

  public guardarJugadores(jugadorX: string, jugadorO: string): void {
    this.jugadorX = jugadorX;
    this.jugadorO = jugadorO;
  }

  public getNombreByFicha(ficha: OPCIONES): string {
    return ficha === OPCIONES.X ? this.jugadorX : ficha === OPCIONES.O ? this.jugadorO : '';
  }
}
