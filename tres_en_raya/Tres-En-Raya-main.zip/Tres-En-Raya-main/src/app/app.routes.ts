import { Routes } from '@angular/router';
import { TableroComponent } from './tablero/tablero.component';
import { ElegirFichaComponent } from './elegir-ficha/elegir-ficha.component';
import { GanadorComponent } from './ganador/ganador.component';

export const routes: Routes = [
    { path: 'ficha', component: ElegirFichaComponent },
    { path: 'partida', component: TableroComponent },
    { path: 'ganador', component: GanadorComponent },
    { path: '', redirectTo: '/ficha', pathMatch: 'full' },
];
