<template>
  <div id="app">
    <!-- Encabezado u otros elementos comunes -->
    <router-view></router-view> <!-- Aquí se mostrarán los componentes de las rutas -->
    <!-- Pie de página u otros elementos comunes -->
  </div>
</template>

<script>
export default {
  // Otros detalles de configuración del componente raíz
}
</script>
