<!-- PostDetail.vue -->

<template>
  <div class="container mt-4">
    <h1>Detalle del Post</h1>
    <div v-if="post">
      <h2>{{ post.titulo }}</h2>
      <p>{{ post.contenido }}</p>
      <!-- Otros detalles del post si los hay -->
    </div>
    <div v-else>
      <p>Cargando...</p>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      post: null
    };
  },
  mounted() {
    this.fetchPost();
  },
  methods: {
    fetchPost() {
      const postId = this.$route.params.id;
      axios.get(`http://localhost:3000/posts/${postId}`)
        .then(response => {
          this.post = response.data;
        })
        .catch(error => {
          console.error('Error al obtener el post:', error);
        });
    }
  }
};
</script>

<style>
/* Estilos adicionales si es necesario */
</style>
