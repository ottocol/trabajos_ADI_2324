<template>
  <div class="container mt-4">
    <h1>Lista de Posts</h1>
    <router-link to="/posts/create" class="btn btn-primary mb-3">Crear Nuevo Post</router-link>
    <div class="list-group">
      <div class="list-group-item list-group-item-primary d-flex justify-content-between align-items-center font-weight-bold">
        <div class="col-2">ID</div>
        <div class="col-8">Título</div>
        <div class="col-2">Acciones</div>
      </div>
      <transition-group name="slide" tag="div">
        <router-link
          v-for="post in posts"
          :key="post.id"
          :to="`/posts/${post.id}`"
          class="list-group-item list-group-item-action d-flex justify-content-between align-items-center slide-item"
        >
          <div class="col-2 text-primary">{{ post.id }}</div>
          <div class="col-8">{{ post.titulo }}</div>
          <div class="col-2">
            <router-link :to="`/posts/${post.id}/edit`" class="btn btn-sm btn-secondary mr-2">Editar</router-link>
            <button @click="eliminarPost(post.id)" class="btn btn-sm btn-danger">Eliminar</button>
          </div>
        </router-link>
      </transition-group>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      posts: []
    };
  },
  mounted() {
    this.fetchPosts();
  },
  methods: {
    fetchPosts() {
      axios.get('http://localhost:3000/posts')
        .then(response => {
          this.posts = response.data;
        })
        .catch(error => {
          console.error('Error al obtener los posts:', error);
        });
    },
    eliminarPost(id) {
      if (confirm('¿Estás seguro de querer eliminar este post?')) {
        axios.delete(`http://localhost:3000/posts/${id}`)
          .then(() => {
            // Actualizar la lista de posts después de eliminar
            this.fetchPosts();
          })
          .catch(error => {
            console.error('Error al eliminar el post:', error);
          });
      }
    }
  }
};
</script>

<style>
/* Resto de estilos se mantienen igual */
.slide-item-enter-active,
.slide-item-leave-active {
  transition: height 0.5s ease-out;
}

.slide-item-enter,
.slide-item-leave-to {
  height: 0;
  overflow: hidden;
}
</style>
