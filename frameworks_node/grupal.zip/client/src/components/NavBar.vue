<template>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
      <router-link to="/" class="navbar-brand">Mi Aplicación</router-link>

      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item" v-if="!isLoggedIn">
            <router-link to="/login" class="nav-link">Iniciar sesión</router-link>
          </li>
          <li class="nav-item" v-if="isLoggedIn">
            <span class="nav-link">{{ userName }}</span>
            <button class="btn btn-link nav-link" @click="logout">Cerrar sesión</button>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      isLoggedIn: false,
      userName: ''
    };
  },
  mounted() {
    this.checkAuthentication();
  },
  methods: {
    checkAuthentication() {
      const token = localStorage.getItem('token');
      if (token) {
        this.isLoggedIn = true;
      }
    },
    logout() {
      axios.post('http://localhost:3000/logout')
        .then(() => {
          localStorage.removeItem('token');
          this.$router.push('/login');
        })
        .catch(error => {
          console.error('Error al cerrar sesión:', error);
        });
    }
  }
};
</script>

<style>
/* Estilos para la barra de navegación si es necesario */
</style>
