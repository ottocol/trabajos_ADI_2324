<template>
  <div>
    <h1>Lista de Usuarios</h1>
    <div v-if="users.length > 0" class="user-list">
      <div v-for="user in users" :key="user.id" class="user-item">
        <p>{{ user.username }}</p>
        <!-- Mostrar más detalles del usuario si es necesario -->
      </div>
    </div>
    <div v-else>
      <p>No hay usuarios disponibles.</p>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      users: []
    };
  },
  mounted() {
    this.fetchUsers();
  },
  methods: {
    fetchUsers() {
      axios.get('http://localhost:3000/usuarios', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      })
      .then(response => {
        this.users = response.data;
      })
      .catch(error => {
        console.error('Error al obtener usuarios:', error);
      });
    }
  }
};
</script>

<style scoped>
/* Estilos específicos del componente si es necesario */
.user-list {
  /* Estilos para la lista de usuarios */
}
.user-item {
  /* Estilos para cada elemento de usuario en la lista */
}
</style>
