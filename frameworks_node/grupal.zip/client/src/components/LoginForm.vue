<template>
  <div class="container mt-4">
    <h1>Iniciar sesión</h1>
    <form @submit.prevent="login">
      <div class="form-group">
        <label for="nombre">Nombre de usuario</label>
        <input type="text" class="form-control" id="nombre" v-model="credentials.nombre">
      </div>
      <div class="form-group">
        <label for="password">Contraseña</label>
        <input type="password" class="form-control" id="password" v-model="credentials.password">
      </div>
      <button type="submit" class="btn btn-primary">Iniciar sesión</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      credentials: {
        nombre: '',
        password: ''
      }
    };
  },
  methods: {
    login() {
      axios.post('http://localhost:3000/login', this.credentials)
        .then(response => {
          // Almacenar el token en el localStorage después del inicio de sesión exitoso
          const token = response.data.token;
          localStorage.setItem('token', token);

          // Redirigir al usuario a la página principal después del inicio de sesión
          this.$router.push('/'); // Cambia '/ruta' por la ruta que desees
        })
        .catch(error => {
          console.error('Error al iniciar sesión:', error);
          // Manejar errores de inicio de sesión, como mostrar un mensaje de error al usuario
        });
    }
  }
};
</script>

<style>
/* Estilos adicionales si es necesario */
</style>
