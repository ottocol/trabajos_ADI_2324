<template>
  <div>
    <!-- Aquí está la barra de navegación que se mostrará en todas las páginas -->
    <NavBar />

    <!-- El router-view contendrá el componente de la página actual -->
    <router-view />
  </div>
</template>

<script>
import NavBar from '@/components/NavBar.vue'; // Importa tu componente de barra de navegación

export default {
  components: {
    NavBar,
  },
};
</script>
