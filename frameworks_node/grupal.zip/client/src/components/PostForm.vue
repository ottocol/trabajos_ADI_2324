<template>
  <div class="container mt-4">
    <h1>{{ editing ? 'Editar Post' : 'Crear Post' }}</h1>
    <form @submit.prevent="handleSubmit">
      <div class="form-group">
        <label for="title">Título:</label>
        <input type="text" class="form-control" v-model="post.titulo" id="title">
      </div>
      <div class="form-group">
        <label for="content">Contenido:</label>
        <textarea class="form-control" v-model="post.contenido" id="content"></textarea>
      </div>
      <button type="submit" class="btn btn-primary">{{ editing ? 'Actualizar' : 'Crear' }} Post</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      post: {
        titulo: '',
        contenido: ''
      },
      editing: false,
      postId: null
    };
  },
  mounted() {
    // Obtener el ID del post si estamos en modo edición
    this.postId = this.$route.params.id;
    if (this.postId) {
      this.editing = true;
      this.fetchPost();
    }
  },
  methods: {
    fetchPost() {
      axios.get(`http://localhost:3000/posts/${this.postId}`)
        .then(response => {
          this.post = response.data;
        })
        .catch(error => {
          console.error('Error al obtener el post:', error);
        });
    },
    handleSubmit() {
      if (this.editing) {
        this.updatePost();
      } else {
        this.createPost();
      }
    },
    createPost() {
      axios.post('http://localhost:3000/posts', this.post)
        .then(() => {
          // Redirigir a la lista de posts después de crear
          this.$router.push('/posts');
        })
        .catch(error => {
          console.error('Error al crear el post:', error);
        });
    },
    updatePost() {
      axios.put(`http://localhost:3000/posts/${this.postId}`, this.post)
        .then(() => {
          // Redirigir a la lista de posts después de actualizar
          this.$router.push('/posts');
        })
        .catch(error => {
          console.error('Error al actualizar el post:', error);
        });
    }
  }
};
</script>

<style>
/* Estilos adicionales si es necesario */
</style>
