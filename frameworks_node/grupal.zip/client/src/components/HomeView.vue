<!-- HomeView.vue -->
<template>
  <div>
    <h1>¡Bienvenido a mi página!</h1>
    <!-- Aquí puedes agregar contenido adicional -->
  </div>
</template>

<script>
export default {
  // Puedes agregar lógica adicional si es necesario
}
</script>

<style>
/* Puedes agregar estilos CSS aquí si lo deseas */
</style>
