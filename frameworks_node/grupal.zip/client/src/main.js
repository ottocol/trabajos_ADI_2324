import { createApp } from 'vue';
import { createRouter, createWebHistory } from 'vue-router';
import App from './App.vue';
import 'bootstrap/dist/css/bootstrap.min.css';
import Layout from './components/LayoutBar.vue'; // Asegúrate de tener un componente Home
import HomeView from './components/HomeView.vue'; // Asegúrate de tener un componente Home
import PostList from './components/PostList.vue'; // Ajusta la ruta según la ubicación real
import PostForm from './components/PostForm.vue'; // Ruta al componente de creación/edición de posts
import PostDetail from './components/PostDetail.vue'; // Ruta al componente de detalle de un post
import Login from './components/LoginForm.vue'; // Ruta al componente de inicio de sesión

const routes = [
    {
        path: '/',
        component: Layout, // Utiliza el layout principal
        children: [
    
  { path: '/', component: HomeView },
  {
    path: '/posts',
    component: PostList
  },
  {
    path: '/posts/create',
    component: PostForm,
    name: 'CreatePost' // Nombre de la ruta para la creación de posts
  },
  {
    path: '/posts/:id/edit',
    component: PostForm,
    name: 'EditPost' // Nombre de la ruta para la edición de posts
  },
  {
    path: '/posts/:id',
    component: PostDetail,
    name: 'PostDetail' // Nombre de la ruta para el detalle de un post
  },
  {
    path: '/login',
    component: Login,
    name: 'Login' // Nombre de la ruta para el inicio de sesión
  }
 ] }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

const app = createApp(App);
app.use(router);
app.mount('#app');
