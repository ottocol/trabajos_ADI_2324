// Importamos el módulo Fastify
const fastify = require('fastify')();
const PORT = process.env.PORT || 3000;
const jwt = require('jwt-simple');
const secretKey = 'achraf123';
const knex = require('knex')(require('./knexfile').development);

// Añadimos el plugin de CORS para manejar la política de mismo origen
fastify.register(require('fastify-cors'));

// Ruta raíz
fastify.get('/', async (request, reply) => {
  return { mensaje: '¡Hola, mundo!' };
});

// Ruta para el inicio de sesión
fastify.post('/login', async (request, reply) => {
  const { nombre, password } = request.body;

  try {
    const user = await knex('usuarios').where({ nombre, password }).first();

    if (!user) {
      reply.status(401).send({ message: 'Credenciales incorrectas' });
    }

    // Generar el token JWT con el nombre de usuario como carga útil
    const payload = {
      nombre: user.nombre // Puedes incluir más información si es necesario
    };
    const token = jwt.encode(payload, secretKey);

    reply.send({ token });
  } catch (error) {
    reply.status(500).send({ error: error.message });
  }
});

// Ruta para cerrar sesión
fastify.post('/logout', async (request, reply) => {
  reply.send({ message: 'Sesión cerrada exitosamente' });
});

// Middleware para verificar el token en rutas protegidas
async function verifyToken(request, reply) {
  const token = request.headers.authorization;

  if (!token) {
    reply.status(403).send({ message: 'Token no proporcionado' });
  }

  try {
    const decoded = jwt.decode(token, secretKey);
    request.user = decoded; // Agregar la información del usuario al objeto de solicitud para su uso posterior
  } catch (error) {
    reply.status(401).send({ message: 'Token inválido' });
  }
}

// Ruta para obtener todos los usuarios
fastify.get('/usuarios', { preHandler: verifyToken }, async (request, reply) => {
  try {
    const usuarios = await knex('usuarios').select('*');
    reply.send(usuarios);
  } catch (error) {
    reply.status(500).send({ error: error.message });
  }
});

// Ruta para obtener un usuario por su ID
fastify.get('/usuarios/:id', { preHandler: verifyToken }, async (request, reply) => {
  const userId = parseInt(request.params.id);
  try {
    const user = await knex('usuarios').where({ id: userId }).first();
    if (user) {
      reply.send(user);
    } else {
      reply.status(404).send({ message: 'Usuario no encontrado' });
    }
  } catch (error) {
    reply.status(500).send({ error: error.message });
  }
});

// Ruta para crear un nuevo usuario
fastify.post('/usuarios', { preHandler: verifyToken }, async (request, reply) => {
  const { username, password } = request.body;
  try {
    const newUser = await knex('usuarios').insert({ username, password });
    reply.status(201).send({ id: newUser[0], username, password });
  } catch (error) {
    reply.status(500).send({ error: error.message });
  }
});

// Ruta para actualizar un usuario por su ID
fastify.put('/usuarios/:id', { preHandler: verifyToken }, async (request, reply) => {
  const userId = parseInt(request.params.id);
  const { username, password } = request.body;
  try {
    const updatedUser = await knex('usuarios')
      .where({ id: userId })
      .update({ username, password });
    if (updatedUser) {
      reply.send({ id: userId, username, password });
    } else {
      reply.status(404).send({ message: 'Usuario no encontrado' });
    }
  } catch (error) {
    reply.status(500).send({ error: error.message });
  }
});

// Ruta para eliminar un usuario por su ID
fastify.delete('/usuarios/:id', { preHandler: verifyToken }, async (request, reply) => {
  const userId = parseInt(request.params.id);
  try {
    const deletedUser = await knex('usuarios').where({ id: userId }).del();
    if (deletedUser) {
      reply.send({ message: 'Usuario eliminado' });
    } else {
      reply.status(404).send({ message: 'Usuario no encontrado' });
    }
  } catch (error) {
    reply.status(500).send({ error: error.message });
  }
});

// Ruta para obtener un post por su ID
fastify.get('/posts/:id', async (request, reply) => {
  const postId = parseInt(request.params.id);
  try {
    const post = await knex('posts').where({ id: postId }).first();
    if (post) {
      reply.send(post);
    } else {
      reply.status(404).send({ message: 'Post no encontrado' });
    }
  } catch (error) {
    reply.status(500).send({ error: error.message });
  }
});

// Ruta para obtener todos los posts
fastify.get('/posts', async (request, reply) => {
  try {
    const posts = await knex('posts').select('*');
    reply.send(posts);
  } catch (error) {
    reply.status(500).send({ error: error.message });
  }
});

// Ruta para crear un nuevo post
fastify.post('/posts', async (request, reply) => {
  const { titulo, contenido } = request.body;
  try {
    const newPost = await knex('posts').insert({ titulo, contenido });
    reply.status(201).send({ id: newPost[0], titulo, contenido });
  } catch (error) {
    reply.status(500).send({ error: error.message });
  }
});

// Ruta para actualizar un post por su ID
fastify.put('/posts/:id', async (request, reply) => {
  const postId = parseInt(request.params.id);
  const { titulo, contenido } = request.body;
  try {
    const updatedPost = await knex('posts')
      .where({ id: postId })
      .update({ titulo, contenido });
    if (updatedPost) {
      reply.send({ id: postId, titulo, contenido });
    } else {
      reply.status(404).send({ message: 'Post no encontrado' });
    }
  } catch (error) {
    reply.status(500).send({ error: error.message });
  }
});

// Ruta para eliminar un post por su ID
fastify.delete('/posts/:id', async (request, reply) => {
  const postId = parseInt(request.params.id);
  try {
    const deletedPost = await knex('posts').where({ id: postId }).del();
    if (deletedPost) {
      reply.send({ message: 'Post eliminado' });
    } else {
      reply.status(404).send({ message: 'Post no encontrado' });
    }
  } catch (error) {
    reply.status(500).send({ error: error.message });
  }
});

// Iniciamos el servidor Fastify
fastify.listen(3000, '0.0.0.0', (err) => {
  if (err) throw err;
  console.log(`Servidor escuchando en http://localhost:3000`);
});

