/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function (knex) {
    return knex('usuarios').insert([
      { nombre: 'usuario1', password: 'contraseña1' },
      { nombre: 'usuario2', password: 'contraseña2' },
      { nombre: 'admin', password: 'admin' },
    ]);
  };
  
  exports.down = function (knex) {
  };
