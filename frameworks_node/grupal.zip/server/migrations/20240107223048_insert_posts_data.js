/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function (knex) {
    return knex('posts').insert([
      { titulo: 'Título del Post 1', contenido: 'Contenido del Post 1' },
      { titulo: 'Título del Post 2', contenido: 'Contenido del Post 2' },
    ]);
  };
  
  exports.down = function (knex) {
  };