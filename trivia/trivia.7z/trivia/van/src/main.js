import van from "vanjs-core";
const { a, div, li, p, ul, span, h2, button, br } = van.tags;

function shuffle(array) {
  let currentIndex = array.length,
    randomIndex;

  while (currentIndex > 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;

    [array[currentIndex], array[randomIndex]] = [
      array[randomIndex],
      array[currentIndex],
    ];
  }

  return array;
}

const Answer = (answer) =>
  button(
    {
      class: "answer",
      onclick: () => {
        selectedAnswer.val = answer;
        checkAnswer();
      },
    },
    answer,
  );

const Title = (title) => span({ class: "question-title" }, title);
const Answers = div({ class: "answers" });
const triviaTitle = van.state("Trivia Game");
const title = van.state("");
const correctAnswer = van.state("");
const selectedAnswer = van.state("");
let questions = [];
let token = null;

function checkAnswer() {
  document.querySelectorAll(".answer").forEach((element) => {
    if (element.innerText == correctAnswer.val) {
      element.innerText += " ✅";
    } else if (
      element.innerText != correctAnswer.val &&
      element.innerText == selectedAnswer.val
    ) {
      element.innerText += " ❌";
    }
  });
  setTimeout(() => {
    displayNextQuestion();
  }, 2000);
}

const Trivia = () =>
  div(
    { id: "wrapper" },
    h2(triviaTitle),
    br(),
    div({ id: "question-wrapper" }, Title(title), Answers),
  );

async function fetchToken() {
  try {
    const t = localStorage.getItem("token");
    if (t) {
      token = t;
      return true;
    }
    const response = await fetch(
      `https://opentdb.com/api_token.php?command=reset&token=${token}`,
      { mode: "cors" },
    );
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    if (data.response_code === 3 || data.response_code === 4) {
      throw new Error("Invalid token");
    }
    localStorage.setItem("token", data.token);
    return true;
  } catch (error) {
    console.error("Failed to fetch token:", error);
    return false;
  }
}

function clearAnswers() {
  document.querySelectorAll(".answer").forEach((element) => {
    element.remove();
  });
}

async function displayNextQuestion() {
  if (questions.length > 0) {
    triviaTitle.val = "Trivia Game";
    const nextQuestion = questions[0];
    const answers = [];

    clearAnswers();
    correctAnswer.val = nextQuestion["correct_answer"];
    answers.push(Answer(nextQuestion["correct_answer"]));
    answers.push(
      nextQuestion["incorrect_answers"].map((answer) => Answer(answer)),
    );
    van.add(Answers, shuffle(answers));
    title.val = nextQuestion["question"];
    questions.shift();
  } else {
    await fetchQuestions();
    displayNextQuestion();
  }
}

async function fetchQuestions(category = undefined) {
  const amount = 10;

  triviaTitle.val = "Trivia Game (loading...)";
  try {
    let response;

    if (!category) {
      response = await fetch(`https://opentdb.com/api.php?amount=${amount}&`);
    } else {
      response = await fetch(
        `https://opentdb.com/api.php?amount=${amount}&token=${token}&category=${category}`,
      );
    }

    if (response.status === 429) {
      throw new Error("Rate limit exceeded");
    }
    let data = await response.json();
    questions = data["results"];
  } catch (error) {
    console.error(error);
  }
}

van.add(document.body, Trivia());

window.onload = async function () {
  await fetchToken();
  await fetchQuestions();
  displayNextQuestion();
};
