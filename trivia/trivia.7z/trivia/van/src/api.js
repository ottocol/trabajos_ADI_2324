import { createStore } from "nanostores";

const token = createStore(() => {});
let questions = [];

function setToken(newToken) {
  token.set(newToken);
}

export function getToken() {
  return token.get();
}

export async function fetchToken() {
  try {
    const response = await fetch(
      `https://opentdb.com/api_token.php?command=reset&token=${token}`,
      { mode: "cors" },
    );
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    if (data.response_code === 3 || data.response_code === 4) {
      throw new Error("Invalid token");
    }
    setToken(data.token);
    return true;
  } catch (error) {
    console.error("Failed to fetch token:", error);
    return false;
  }
}

let currentQuestionIndex = 0;

function displayNextQuestion() {
  if (questions.length > 0) {
    const nextQuestion = questions[currentQuestionIndex];
    currentQuestionIndex++;
  } else {
    console.log("No more questions.");
  }
}

export async function fetchQuestions({ category }) {
  const token = localStorage.getItem("token");

  try {
    let response;

    if (category) {
      response = await fetch(
        `https://opentdb.com/api.php?amount=15&token=${token}`,
      );
    } else {
      response = await fetch(
        `https://opentdb.com/api.php?amount=15&token=${token}&category=${this.categoryId}`,
      );
    }

    if (response.status === 429) {
      throw new Error("Rate limit exceeded");
    }
    let data = await response.json();
    if (data.response_code === 1) {
      await delay(2000);
      this.goToMenu();
    }
    return data["results"];
  } catch (error) {
    await this.delay(6000);
    return await this.fetchQuestions();
  }
}
