<template>
  <main>
    <div class="wrapper">
      <div class="title-div" @click="goToMenu">
        <h1 class="title">Trivia Game</h1>
        <h3 class="hidden-text">Go to the main menu</h3>
      </div>
      <h2>Points: {{ punctuation }}</h2>
      <div class="wrapper" v-if="question">
        <div class="notification trivia-category" :data-category-name="question.category">
          <div class="notiglow"></div>
          <div class="notiborderglow"></div>
          <div class="notititle trivia-category" :data-category-name="question.category">{{ question.category }}</div>
          <div class="notibody">{{ question.question }}</div>
        </div>
        <button class="answer" v-for="(answer, index) in answers" :key="index" @click="checkAnswer(answer, $event)">
          {{ answer }}
        </button>
      </div>
      <div v-else>
        <div class="loading-notification"></div>
        <button class="answer loading"></button>
        <button class="answer loading"></button>
        <button class="answer loading"></button>
        <button class="answer loading"></button>
      </div>
    </div>
  </main>
</template>

<script>
export default {
  data() {
    return {
      punctuation: 0,
      questions: [],
      question: null,
      answers: [],
      correctAnswer: null,
      token: null,
      categoryId: null,
    }
  },
  created() {
    this.categoryId = this.$route.params.categoryId
  },
  async mounted() {
    // Get a token
    this.token = await this.fetchToken()
    // Get questions
    this.questions = await this.fetchQuestions()
    await this.getQuestion()
  },
  methods: {
    async fetchToken() {
      // Check if there is a valid token in the localStorage
      const token = localStorage.getItem('token');

      try {
        let response = await fetch(`https://opentdb.com/api_token.php?command=reset&token=${token}`, { mode: 'cors' });
        let data = await response.json();
        if (data.response_code === 3 || data.response_code === 4) {
          throw new Error('Invalid token');
        }

        // Save token in the localStorage
        localStorage.setItem('token', data.token);
        return data.token;
      } catch (error) {
        // Otherwise get a new token
        let response = await fetch('https://opentdb.com/api_token.php?command=request', { mode: 'cors' });
        let data = await response.json();
        // Save token in the localStorage
        localStorage.setItem('token', data.token);
        return data.token;
      }
    },
    async fetchQuestions() {
      // Get token from localStorage
      const token = localStorage.getItem('token')

      try {
        // Fetch questions
        let response;
        if (this.categoryId == 0) {
          response = await fetch(`https://opentdb.com/api.php?amount=15&token=${token}`);
        } else {
          response = await fetch(`https://opentdb.com/api.php?amount=15&token=${token}&category=${this.categoryId}`)
        }

        // Check if status is 429
        if (response.status === 429) {
          throw new Error('Rate limit exceeded')
        }
        let data = await response.json();
        if(data.response_code === 1) {
          await delay(2000)
          this.goToMenu()
        }
        // Handle the JSON data here
        return data['results'];
      } catch (error) {
        // Wait for 5 seconds before fetching questions again
        await this.delay(6000);
        return await this.fetchQuestions();
      }
    },
    async getQuestion() {
      // Retrieve more questions if there are less than 5 questions left
      if (this.questions.length < 5) {
        this.questions = this.questions.concat(await this.fetchQuestions())
      }

      // Get the first question
      this.question = this.questions[0]
      this.question.question = this.decodeHtml(this.question.question)
      this.question.category = this.decodeHtml(this.question.category)
      // Remove the first question from the array
      this.questions = this.questions.slice(1)
      // Decode the answers
      this.question.correct_answer = this.decodeHtml(this.question.correct_answer)
      this.correctAnswer = this.question.correct_answer
      this.question.incorrect_answers = this.question.incorrect_answers.map(answer => this.decodeHtml(answer));
      // Shuffle the answers
      let answers = [this.question.correct_answer, ...this.question.incorrect_answers]
      for (let i = answers.length - 1; i > 0; i--) {
        let j = this.getRandomInt(0, i);
        [answers[i], answers[j]] = [answers[j], answers[i]]
      }

      this.answers = answers
    },
    async checkAnswer(answer, event) {
      // Get all the buttons with the answers
      const buttons = document.querySelectorAll('.answer');

      // Disable all the buttons
      buttons.forEach(button => {
        button.disabled = true;
      });

      if (answer === this.correctAnswer) {
        // Change the color of the button to green
        event.target.classList.add('correct')
        this.punctuation += 1
      } else {
        // Change the color of the button to red
        event.target.classList.add('wrong')
        // Change the color of the correct answer to green
        buttons.forEach(button => {
          if (button.textContent === this.correctAnswer) {
            button.classList.add('correct');
          }
        });
      }

      // Wait for 2 seconds before showing the next question
      setTimeout(() => {
        buttons.forEach(button => {
          button.classList.remove('correct', 'wrong');
        });
        this.getQuestion()
        // Enable all the buttons
        buttons.forEach(button => {
          button.disabled = false;
        });

      }, 1000);
    },
    goToMenu() {
      this.$router.push({ name: 'home' })
    },
    decodeHtml(htmlString) {
      const parser = new DOMParser();
      const decodedHtml = parser.parseFromString(htmlString, 'text/html');
      return decodedHtml.body.textContent || "";
    },
    getRandomInt(min, max) {
      min = Math.ceil(min)
      max = Math.floor(max)
      return Math.floor(Math.random() * (max - min + 1)) + min
    },
    async delay(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    },
  }
}
</script>

<style scoped>
main {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.title-div {
  cursor: pointer;
}

.title {
  text-align: center;
}

.hidden-text {
  opacity: 0;
  visibility: hidden;
  text-align: center;
  transition: opacity 0.5s ease-in-out, visibility 0.5s;
  color: #4e4e4e;
}

.title-div:hover .hidden-text {
  opacity: 1;
  visibility: visible;
}

.answer {
  font-family: PlusJakartaSans, -apple-system, BlinkMacSystemFont, Segoe UI,
    Roboto, Oxygen, Cantarell, Helvetica Neue, Ubuntu, sans-serif;
  font-size: 1rem;
  align-items: center;
  border-radius: 0.4rem;
  font-weight: 600;
  padding: 1rem 4.2rem;
  margin: 0.5rem 0;
  color: #ddd;
  border: none;
  cursor: pointer;
  box-shadow: 0 0.5rem 1rem rgba(143, 142, 142, 0.15) !important;
  background: #242424;
  display: block;
  width: 25rem;
}

.answer:hover {
  background: #2b2a2a;
}

.correct {
  background-color: rgb(58, 137, 58);
}

.correct:hover {
  background-color: rgb(51, 123, 51);
}

.wrong {
  background-color: rgb(165, 70, 70);
}

.wrong:hover {
  background-color: rgb(143, 57, 57);
}

.notification {
  display: flex;
  flex-direction: column;
  isolation: isolate;
  position: relative;
  width: 25rem;
  min-height: 10rem;
  background: #29292c;
  border-radius: 1rem;
  overflow: hidden;
  font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
  font-size: 16px;
}

.notification:before {
  position: absolute;
  content: "";
  inset: 0.0625rem;
  border-radius: 0.9375rem;
  background: #18181b;
  z-index: 2
}

.notification:after {
  position: absolute;
  content: "";
  width: 0.25rem;
  inset: 0.65rem auto 0.65rem 0.5rem;
  border-radius: 0.125rem;
  background: var(--color);
  transition: transform 300ms ease;
  z-index: 4;
}

.notification:hover:after {
  transform: translateX(0.15rem)
}

.notititle {
  color: var(--color);
  padding: 0.65rem 0.25rem 0.4rem 1.25rem;
  font-weight: 500;
  font-size: 1.1rem;
  transition: transform 300ms ease;
  z-index: 5;
}

.notification:hover .notititle {
  transform: translateX(0.15rem)
}

.notibody {
  color: #99999d;
  padding: 1.25rem;
  padding-top: 0rem;
  transition: transform 300ms ease;
  z-index: 5;
}

.notification:hover .notibody {
  transform: translateX(0.25rem)
}

.notiglow,
.notiborderglow {
  position: absolute;
  width: 20rem;
  height: 20rem;
  transform: translate(-50%, -50%);
  background: radial-gradient(circle closest-side at center, white, transparent);
  opacity: 0;
  transition: opacity 300ms ease;
}

.notiglow {
  z-index: 3;
}

.notiborderglow {
  z-index: 1;
}

.notification:hover .notiglow {
  opacity: 0.1
}

.notification:hover .notiborderglow {
  opacity: 0.1
}

.note {
  color: var(--color);
  position: fixed;
  top: 80%;
  left: 50%;
  transform: translateX(-50%);
  text-align: center;
  font-size: 0.9rem;
  width: 75%;
}

@keyframes glow {
  0% {
    background-position: -200px;
  }

  50% {
    background-color: #838383;
  }

  100% {
    background-position: calc(200px + 100%);
  }
}

.loading {
  background: #838383 linear-gradient(90deg, transparent, rgba(94, 94, 94, 0.5), transparent) repeat;
  background-size: 200px 100%;
  animation: glow 2s linear infinite;
}

.loading-notification {
  display: flex;
  flex-direction: column;
  isolation: isolate;
  position: relative;
  width: 25rem;
  min-height: 10rem;
  background: #838383;
  border-radius: 1rem;
}

/* Colores para cada categoría */
.trivia-category {
  --color: #9b59b6; /* Default color */
  color: var(--color);
}

.trivia-category[data-category-name="General Knowledge"] {
  --color: #3498db;
  /* Azul */
}

.trivia-category[data-category-name="Entertainment: Books"] {
  --color: #2ecc71;
  /* Verde */

}

.trivia-category[data-category-name="Entertainment: Film"] {
  --color: #e74c3c;
  /* Rojo */

}

.trivia-category[data-category-name="Entertainment: Music"] {
  --color: #f39c12;
  /* Amarillo */

}

.trivia-category[data-category-name="Entertainment: Musicals & Theatres"] {
  --color: #9b59b6;
  /* Morado */

}

.trivia-category[data-category-name="Entertainment: Television"] {
  --color: #3498db;
  /* Azul */

}

.trivia-category[data-category-name="Entertainment: Video Games"] {
  --color: #2ecc71;
  /* Verde */

}

.trivia-category[data-category-name="Entertainment: Board Games"] {
  --color: #e74c3c;
  /* Rojo */

}

.trivia-category[data-category-name="Science & Nature"] {
  --color: #f39c12;
  /* Amarillo */

}

.trivia-category[data-category-name="Science: Computers"] {
  --color: #9b59b6;
  /* Morado */

}

.trivia-category[data-category-name="Science: Mathematics"] {
  --color: #3498db;
  /* Azul */

}

.trivia-category[data-category-name="Mythology"] {
  --color: #2ecc71;
  /* Verde */

}

.trivia-category[data-category-name="Sports"] {
  --color: #e74c3c;
  /* Rojo */

}

.trivia-category[data-category-name="Geography"] {
  --color: #f39c12;
  /* Amarillo */

}

.trivia-category[data-category-name="History"] {
  --color: #9b59b6;
  /* Morado */

}

.trivia-category[data-category-name="Politics"] {
  --color: #3498db;
  /* Azul */

}

.trivia-category[data-category-name="Art"] {
  --color: #2ecc71;
  /* Verde */

}

.trivia-category[data-category-name="Celebrities"] {
  --color: #e74c3c;
  /* Rojo */

}

.trivia-category[data-category-name="Animals"] {
  --color: #f39c12;
  /* Amarillo */

}

.trivia-category[data-category-name="Vehicles"] {
  --color: #9b59b6;
  /* Morado */

}

.trivia-category[data-category-name="Entertainment: Comics"] {
  --color: #3498db;
  /* Azul */

}

.trivia-category[data-category-name="Science: Gadgets"] {
  --color: #2ecc71;
  /* Verde */

}

.trivia-category[data-category-name="Entertainment: Japanese Anime & Manga"] {
  --color: #e74c3c;
  /* Rojo */
}

.trivia-category[data-category-name="Entertainment: Cartoon & Animations"] {
  --color: #f39c12;
  /* Amarillo */

}
</style>