<template>
  <main>
    <h1 class="title">Trivia Game</h1>
    <select v-model="selectedCategory">
      <option disabled value="Any Category">Please select a category</option>
      <option v-for="(category, index) in categories" :key="index" :value="category">
        {{ category.name }}
      </option>
    </select>
    <button @click="startGame">
      Play
    </button>
  </main>
</template>

<script>
export default {
  data() {
    return {
      categories: [],
      selectedCategory: null,
    }
  },
  async created() {
    await this.fetchCategories()
  },
  methods: {
    startGame() {
      this.$router.push({ name: 'game', params: { categoryId: this.selectedCategory.id } })
    },
    async fetchCategories() {
      fetch('https://opentdb.com/api_category.php')
        .then((response) => response.json())
        .then((data) => {
          this.categories = [{ id: 0, name: "Any Category" }].concat(data.trivia_categories);
          this.selectedCategory = this.categories[0];
          console.log(this.categories)
        })
        .catch((error) => {
          console.error(error)
        })
    },
  }
}
</script>

<style scoped>
main {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.title {
  text-align: center;
}

select {
  font-family: PlusJakartaSans, -apple-system, BlinkMacSystemFont, Segoe UI,
    Roboto, Oxygen, Cantarell, Helvetica Neue, Ubuntu, sans-serif;
  font-size: 1rem;
  max-height: 5rem;
  overflow-y: auto;
  color: #ddd;
  background-color: #000000;
  border-radius: 0.4rem;
  border: none;
  padding: 1rem;
  margin: 0 0 2rem 0;
  display: block;
}

button {
  font-family: PlusJakartaSans, -apple-system, BlinkMacSystemFont, Segoe UI,
    Roboto, Oxygen, Cantarell, Helvetica Neue, Ubuntu, sans-serif;
  font-size: 1rem;
  align-items: center;
  height: 48px;
  border-radius: 0.4rem;
  font-weight: 600;
  padding: 0 4.2rem;
  color: #ddd;
  border: none;
  cursor: pointer;
  box-shadow: 0 0.5rem 1rem rgba(143, 142, 142, 0.15) !important;
  background: #000000;
  display: block;
}

button:hover {
  background: #2b2a2a;
}
</style>
