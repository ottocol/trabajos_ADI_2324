// App.jsx

import React, { useEffect } from 'react';
import { Route, Routes } from 'react-router-dom';
import Home from './routes/Home';
import NavBar from './components/NavBar';
import RegisterForm from './components/RegisterForm';
import LoginForm from './components/LoginForm';
import Perfil from './components/Perfil';
import AddPost from './components/AddPost'; // Importamos AddPost


const App = () => {
  // UseEffect para hacer lo que quieras al recargar la página
  useEffect(() => {
    
  }, []);

  return (
    <div className="bg-zinc-950">
      <NavBar />
      <div className="min-h-screen">
        <Routes>
          <Route path="/" element={<LoginForm />} />
          <Route path="/home" element={<Home />} />
          <Route path="/register" element={<RegisterForm />} />
          <Route path="/login" element={<LoginForm />} />
          <Route path="/perfil" element={<Perfil />} />
          <Route path="/addpost" element={<AddPost />} />
         
        </Routes>
      </div>
    </div>
  );

};

export default App;
