// routes/Home.jsx

import React, { useState, useEffect } from 'react';
import { getPostsRequest } from '../api/apis'; 
import PostCard from '../components/PostCard';
import { Link } from 'react-router-dom'; // Agregamos la importación

function Home() {
    const [posts, setPosts] = useState([]);

    useEffect(() => {
        const fetchPosts = async () => {
            try {
                const fetchedPosts = await getPostsRequest();
                setPosts(fetchedPosts);
            } catch (error) {
                console.error('Error fetching posts:', error);
            }
        };

        fetchPosts();
    }, []);

    return (
        <div className='grid grid-cols-1 gap-4 p-4'>
            <Link to="/addpost" className="bg-blue-500 text-white py-2 px-4 rounded mb-4">Agregar Post</Link>
            {posts.map(post => (
                <PostCard key={post.id} post={post} />
            ))}
        </div>
    );
}

export default Home;
