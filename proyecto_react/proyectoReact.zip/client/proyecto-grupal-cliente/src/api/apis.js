import axios from 'axios';

export const getPostsRequest = async () => {
  try {
    const jwtToken = localStorage.getItem('jwtToken'); // Obtener el token del estado local

    const response = await axios.get('http://localhost:3000/posts', {
      headers: {
        Authorization: `Bearer ${jwtToken}`,
      },
    });

    return response.data; // Devuelve los datos de los posts
  } catch (error) {
    console.error('Error fetching posts:', error);
    throw error;
  }
};

export const getUserInfo = async () => {
  try {
    const jwtToken = localStorage.getItem('jwtToken'); // Obtener el token del estado local

    const response = await axios.get('http://localhost:3000/user', {
      headers: {
        Authorization: `Bearer ${jwtToken}`,
      },
    });
    console.log(response.data)
    return response.data; // Devuelve los datos de los posts
  } catch (error) {
    console.error('Error fetching posts:', error);
    throw error;
  }
};



export const getPostsUserRequest = async () => {
  try {
    const jwtToken = localStorage.getItem('jwtToken'); // Obtener el token del estado local

    const response = await axios.get('http://localhost:3000/postsUser', {
      headers: {
        Authorization: `Bearer ${jwtToken}`,
      },
    });

    return response.data; // Devuelve los datos de los posts
  } catch (error) {
    console.error('Error fetching posts:', error);
    throw error;
  }
};

export const registerUser = async (userData) => {
  try {
    const response = await axios.post('http://localhost:3000/register', userData);
    return response.data;
  } catch (error) {
    console.error('Error registering user:', error);
    throw error;
  }
};

export const loginUser = async (userData) => {
  try {
    const response = await axios.post('http://localhost:3000/login', userData);
    return response.data;
  } catch (error) {
    console.error('Error logging in:', error);
    throw error;
  }
};

export const logoutUser = async () => {
  try {
    const response = await axios.post('http://localhost:3000/logout');
    return response.data;
  } catch (error) {
    console.error('Error logging out:', error);
    throw error;
  }
};

export const addPostRequest = async (postData) => {
  try {
      const jwtToken = localStorage.getItem('jwtToken');
      const response = await axios.post('http://localhost:3000/addpost', postData, {
          headers: {
              Authorization: `Bearer ${jwtToken}`,
          },
      });
      return response.data;
  } catch (error) {
      console.error('Error adding post:', error);
      throw error;
  }
};