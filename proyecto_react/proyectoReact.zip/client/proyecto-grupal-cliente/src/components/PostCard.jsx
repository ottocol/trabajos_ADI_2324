import React from 'react';

function PostCard({ post }) {
  return (
    <div className='bg-white rounded-lg p-4 shadow-md mb-16 ml-32 mr-32'>
      <h2 className='text-xl font-bold mb-2'>{post.titulo}</h2>
      <img src={'../src/assets/' + post.foto_url} alt={post.titulo} className='w-full rounded mb-2' />
      <p>{post.descripcion}</p>
    </div>
  );
}

export default PostCard;