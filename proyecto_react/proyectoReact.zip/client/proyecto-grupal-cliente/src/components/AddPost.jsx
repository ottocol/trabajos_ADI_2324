import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { addPostRequest } from '../api/apis';

const AddPost = () => {
  const [formData, setFormData] = useState({
    titulo: '',
    descripcion: '',
    foto: null, // Nuevo campo para la foto
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleFileChange = (e) => {
    setFormData({
      ...formData,
      foto: e.target.files[0], // Obtener el primer archivo seleccionado
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    try {
      const formDataToSend = new FormData();
      formDataToSend.append('foto', formData.foto);
      formDataToSend.append('titulo', formData.titulo);
      formDataToSend.append('descripcion', formData.descripcion);
  
      const result = await addPostRequest(formDataToSend);
  
      // Si la adición de post es exitosa, vuelve a la página de inicio
      navigate('/home');
    } catch (error) {
      console.error('Error during adding post:', error);
    }
  };
  

  return (
    <form className="max-w-md mx-auto mt-8" onSubmit={handleSubmit}>
      <div className="mb-4">
        <label className="block text-white text-sm font-bold mb-2" htmlFor="titulo">
          Título
        </label>
        <input
          type="text"
          id="titulo"
          name="titulo"
          className="w-full p-2 border-b-2 border-gray-500 outline-none focus:border-blue-500"
          onChange={handleChange}
          required
        />
      </div>
      <div className="mb-4">
        <label className="block text-white text-sm font-bold mb-2" htmlFor="descripcion">
          Descripción
        </label>
        <textarea
          id="descripcion"
          name="descripcion"
          className="w-full p-2 border-b-2 border-gray-500 outline-none focus:border-blue-500"
          onChange={handleChange}
          required
        ></textarea>
      </div>
      <div className="mb-4">
        <label className="block text-white text-sm font-bold mb-2" htmlFor="foto">
          Foto
        </label>
        <input
          type="file"
          id="foto"
          name="foto"
          accept="image/*" // Solo permitir archivos de imagen
          onChange={handleFileChange}
        />
        {formData.foto && (
          <p className="text-white mt-2">Archivo seleccionado: {formData.foto.name}</p>
        )}
      </div>
      <button type="submit" className="bg-blue-500 text-white py-2 px-4 rounded">
        Agregar Post
      </button>
      <button
        type="button"
        className="bg-gray-500 text-white py-2 px-4 rounded ml-2"
        onClick={() => navigate('/home')}
      >
        Cancelar
      </button>
    </form>
  );
};

export default AddPost;