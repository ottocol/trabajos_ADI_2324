import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { logoutUser } from '../api/apis';

const NavBar = () => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      // Realiza la solicitud de logout al servidor
      await logoutUser();

      // Elimina el token del local storage
      localStorage.removeItem('jwtToken');

      // Redirige al usuario a la página de inicio de sesión
      navigate('/');
    } catch (error) {
      console.error('Error during logout:', error);
    }
  };

  // Obtén el token del local storage
  const jwtToken = localStorage.getItem('jwtToken');

  return (
    <div className="text-white flex justify-between px-10 py-2 mx-2">
      <h1 className="font-bold text-4xl"><Link to="/">Proyecto ADI</Link></h1>
      <ul className="flex justify-between items-center px-10">
        {jwtToken ? (
          <>
            <li className="px-3"><Link to="/home">Home</Link></li>
            <li className="px-3"><button onClick={handleLogout}>Logout</button></li>
            <li className='px-3'><Link to ="/perfil">Ver perfil</Link></li>
          </>
        ) : (
          <>
            <li className="px-3"><Link to="/">Inicio Sesión</Link></li>
            <li className="px-3"><Link to="/register">Registro</Link></li>
          </>
        )}
      </ul>
    </div>
  );
};

export default NavBar;

