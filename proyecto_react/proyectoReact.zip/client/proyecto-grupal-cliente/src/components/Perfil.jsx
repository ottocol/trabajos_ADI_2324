import React, { useState, useEffect } from 'react';
import { getPostsUserRequest, getUserInfo } from '../api/apis'; 
import PostCard from '../components/PostCard';

function Perfil() {
    const [posts,setPosts] = useState([]);
    const [user, setUser] = useState([]);
  
    useEffect(() => {
      const fetchPosts = async () => {
        try {
          
          const fetchedPosts = await getPostsUserRequest();
          setPosts(fetchedPosts);
        } catch (error) {
          // Manejar el error, mostrar mensaje, etc.
          console.error('Error fetching posts:', error);
        }
      };
      const fetchInforUser = async() =>{
        try{
            const UserInfor = await getUserInfo();
            setUser(UserInfor);
        }
        catch(error){
            console.error('Error fetching User Info:', error);
        }
      }
      fetchInforUser();
      fetchPosts();
      console.log(user);
    }, []);
  
    return (
        <>
        <div className='bg-white w-56 mx-auto mt-10 mb-10 p-4 rounded-lg'>
            <div className="flex items-center justify-between mb-2">
                <img className="w-10 h-10 rounded-full" src="./src/assets/profilefoto.jpg" alt="Jese Leos"></img>
            </div>
            <p className="text-base font-semibold leading-none text-gray-900 dark:text-white">
                <a href="#"> Perfil de: {user.username}</a>
            </p>
            <p className="mb-3 text-sm font-normal">
                <a href="#" className="hover:underline">Email: {user.email}</a>
            </p>
            
        </div>


        <div className='grid grid-cols-3 gap-1 p-1'>
            {posts.map(post => (
            <PostCard key={post.id} post={post} />
            ))}
        </div>
      </>
      
    );
  }
  
  export default Perfil;