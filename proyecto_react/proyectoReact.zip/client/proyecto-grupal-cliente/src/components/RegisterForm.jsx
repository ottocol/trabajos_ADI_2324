import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { registerUser } from '../api/apis';

const RegisterForm = () => {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    email: '',
  });

  const [error, setError] = useState(null);

  const navigate = useNavigate(); // Obtener el objeto de historial

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Validación de email
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        setError('Invalid email format');
        return;
      }

      const result = await registerUser(formData);
      navigate('/login');
    } catch (error) {
      console.error('Error during registration:', error); // Manejar otros errores, como problemas de red
      setError(error.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <form className="max-w-md mx-auto mt-8" onSubmit={handleSubmit}>
      <div className="mb-4">
        <label className="block text-white text-sm font-bold mb-2" htmlFor="username">
          Username
        </label>
        <input
          type="text"
          id="username"
          name="username"
          className="w-full p-2 border-b-2 border-gray-500 outline-none focus:border-blue-500"
          onChange={handleChange}
          required
        />
      </div>
      <div className="mb-4">
        <label className="block text-white text-sm font-bold mb-2" htmlFor="password">
          Password
        </label>
        <input
          type="password"
          id="password"
          name="password"
          className="w-full p-2 border-b-2 border-gray-500 outline-none focus:border-blue-500"
          onChange={handleChange}
          required
        />
      </div>
      <div className="mb-4">
        <label className="block text-white text-sm font-bold mb-2" htmlFor="email">
          Email
        </label>
        <input
          type="email"
          id="email"
          name="email"
          className="w-full p-2 border-b-2 border-gray-500 outline-none focus:border-blue-500"
          onChange={handleChange}
          required
        />
      </div>
      {error && <span className="text-red-500">{error}</span>}
      <button type="submit" className="bg-blue-500 text-white py-2 px-4 rounded">
        Register
      </button>
    </form>
  );
};

export default RegisterForm;
