const express = require('express')
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
var sqlite3 = require("sqlite3").verbose();
const app = express()
const port = 3000

const multer = require('multer');
const fs = require('fs');
const path = require('path');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Directorio de destino para los archivos subidos
  },
  filename: (req, file, cb) => {
    const fileName = `${file.originalname}`; // Usa un nombre único
    cb(null, fileName);
  },
});
const upload = multer({ storage: storage });
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

var cors = require('cors');
var corsOptions = {
  origin: "http://localhost:5173"
};

//bd
var db = new sqlite3.Database(
    "./bd.sqlite",
    sqlite3.OPEN_READWRITE,
    (err) => {
        if (err) {
        console.error("Error al conectar a la base de datos:", err.message);
        } else {
        console.log("Conexion exitosa a la base de datos SQLite");
        }
    }
);

/*
// Creación de tablas
db.run(`CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    password TEXT,
    email TEXT
)`);

db.run(`CREATE TABLE IF NOT EXISTS Post (
    id INTEGER PRIMARY KEY,
    titulo TEXT,
    descripcion TEXT,
    foto_url TEXT,
    usuario_id INTEGER,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
)`);

// Consultas de inserción
db.run("INSERT INTO usuarios (username, password, email) VALUES ('Paco', '123', 'paco@example.com')");
db.run("INSERT INTO usuarios (username, password, email) VALUES ('Noel', '123', 'noel@example.com')");
db.run("INSERT INTO usuarios (username, password, email) VALUES ('Josi', '123', 'josi@example.com')");
db.run("INSERT INTO usuarios (username, password, email) VALUES ('Juan Carlos', '123', 'jc@example.com')");


db.run("INSERT INTO Post (titulo, descripcion, foto_url, usuario_id) VALUES ('Nueva York', 'Ciudad de Nueva York, EE.UU', 'newyork.jpg', 1)");
db.run("INSERT INTO Post (titulo, descripcion, foto_url, usuario_id) VALUES ('Torre Eiffel', 'Ciudad de Paris, Francia', 'torreeiffel.jpg', 2)");
db.run("INSERT INTO Post (titulo, descripcion, foto_url, usuario_id) VALUES ('Torre de Pisa', 'Ciudad de Pisa, Italia', 'pisa.jpg', 3)");
db.run("INSERT INTO Post (titulo, descripcion, foto_url, usuario_id) VALUES ('Cartel de Hollywood', 'Ciudad de Los Ángeles, EE.UU', 'hollywood.jpg', 3)");
db.run("INSERT INTO Post (titulo, descripcion, foto_url, usuario_id) VALUES ('Catedral de Salamanca', 'Ciudad de Salamanca, España', 'salamanca.jpg', 2)");
*/


//middlewares
app.use(cors(corsOptions));
app.use(bodyParser.json());

//rutas
app.get('/', (req, res) => {
  res.send('Hello World!')
})

// Ruta protegida con JWT
// TENEIS QUE USAR LAS RUTAS DE ESTA MANERA PARA INDICAR QUE LA RUTA NECESITA INICIO DE SESIÓN
app.get('/posts', verifyToken ,(req,res)=>{
  const query = "select * from post";
  db.all(query, [], (err,rows)=>{
    if (err) {
      res.status(500).json({ error: "Error al obtener la lista de posts." });
    } else {
      res.json(rows);
    }
  })
})

app.get('/user', verifyToken, (req, res) => {
  const userId = req.userId;
  const query = "SELECT username, email FROM usuarios WHERE id = ?";
  
  db.get(query, [userId], (err, row) => {
    if (err) {
      res.status(500).json({ error: "Error al obtener la información del usuario." });
    } else {
      if (row) {
        // Si se encuentra un usuario con el ID proporcionado
        const userData = {
          username: row.username,
          email: row.email
        };
        res.json(userData);
      } else {
        // Si no se encuentra ningún usuario con el ID proporcionado
        res.status(404).json({ error: "Usuario no encontrado." });
      }
    }
  });
});


app.get('/postsUser/', verifyToken, (req, res) => {
  const userId = req.userId; // Obtén el ID de usuario de los parámetros de la ruta
  const query = 'SELECT * FROM post WHERE usuario_id = ?'; // Asumiendo que hay una columna 'user_id' en tu tabla de posts

  db.all(query, [userId], (err, rows) => {
    if (err) {
      res.status(500).json({ error: 'Error al obtener la lista de posts.' });
    } else {
      res.json(rows);
    }
  });
});


// Registro de usuario
app.post('/register', async (req, res) => {
  try {
    const { username, password, email } = req.body;

    // Verificar si el usuario ya existe
    const userExists = await checkUserExists(username);
    if (userExists) {
      return res.status(400).json({ error: 'El usuario ya existe.' });
    }

    // Hash de la contraseña
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insertar usuario en la base de datos
    const insertQuery = 'INSERT INTO usuarios (username, password, email) VALUES (?, ?, ?)';
    db.run(insertQuery, [username, hashedPassword, email], (err) => {
      if (err) {
        return res.status(500).json({ error: 'Error al registrar el usuario.' });
      }
      res.status(201).json({ message: 'Usuario registrado exitosamente.' });
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error interno del servidor.' });
  }
});

// Inicio de sesión
app.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    // Obtener el usuario de la base de datos
    const selectQuery = 'SELECT * FROM usuarios WHERE username = ?';
    db.get(selectQuery, [username], async (err, user) => {
      if (err) {
        return res.status(500).json({ error: 'Error al realizar la consulta.' });
      }

      // Verificar si el usuario existe y la contraseña es válida
      if (user && await bcrypt.compare(password, user.password)) {
        // Generar y enviar el token JWT
        const token = jwt.sign({ userId: user.id, username: user.username }, 'secret-key', { expiresIn: '1h' });
        res.json({ token });
      } else {
        res.status(401).json({ error: 'Credenciales inválidas.' });
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error interno del servidor.' });
  }
});

// Función para verificar el token
function verifyToken(req, res, next) {
  const authHeader = req.headers['authorization'];

  if (!authHeader) {
    return res.status(403).json({ error: 'Acceso no autorizado.' });
  }

  const token = authHeader.split(' ')[1]; // Obtener solo el token, eliminando "Bearer"

  if (!token) {
    return res.status(403).json({ error: 'Acceso no autorizado.' });
  }

  jwt.verify(token, 'secret-key', (err, decoded) => {
    if (err) {
      return res.status(401).json({ error: 'Token inválido.' });
    }
    req.userId = decoded.userId;
    next();
  });
}

// Función para verificar si un usuario ya existe
function checkUserExists(username) {
  return new Promise((resolve, reject) => {
    const selectQuery = 'SELECT * FROM usuarios WHERE username = ?';
    db.get(selectQuery, [username], (err, user) => {
      if (err) {
        reject(err);
      } else {
        resolve(!!user);
      }
    });
  });
}

app.post('/logout', (req, res) => {
  res.json({ message: 'Sesión cerrada exitosamente.' });
});

// Añadir un post
app.post('/addpost', verifyToken, upload.single('foto'), (req, res) => {
  try {
    const { titulo, descripcion } = req.body;
    const userId = req.userId;
    const foto_url = req.file.filename;

    const insertQuery = 'INSERT INTO Post (titulo, descripcion, foto_url, usuario_id) VALUES (?, ?, ?, ?)';
    db.run(insertQuery, [titulo, descripcion, foto_url, userId], (err) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Error al agregar el post.' });
      }

      // Copiar la imagen al cliente después de agregar el post
      const sourcePath = path.join(__dirname, 'uploads', foto_url);
      const destPath = path.join(__dirname, '..', 'client', 'proyecto-grupal-cliente', 'src', 'assets', foto_url);

      try {
        fs.copyFileSync(sourcePath, destPath);
        console.log('Imagen copiada exitosamente al cliente.');
      } catch (copyErr) {
        console.error('Error al copiar la imagen al cliente:', copyErr);
      }

      res.status(201).json({ message: 'Post agregado exitosamente.' });
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error interno del servidor.' });
  }
});





app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})