<script>
  import { items } from "./stores";
  import ItemList from "./lib/ItemList.svelte";
  import ItemForm from "./lib/ItemForm.svelte";
</script>

{#await items.fetchItemsTask}
  <h1>Loading todos...</h1>
{:then}
  <main>
    <div >
      <ItemForm></ItemForm>
    </div>

    <div class="row">
      <div class="center">
        <h3>To do</h3>
        <ItemList predicate={(i) => !i.completed}></ItemList>
      </div>
  
      <div class="center">
        <h3>Done</h3>
        <ItemList predicate={(i) => i.completed}></ItemList>
      </div>
    </div>
  </main>
{/await}

<style>
  .row {
    display: flex;
    flex-direction: row;
  }
  .center {
    width:50%;
  }
</style>
