<script>
  import { items } from "../stores";

  let title = "";
  let description = "";

  function handleSubmit() {
    items.addItem({ title, description });

    title = "";
    description = "";
  }
</script>

<div class="item">
  <form on:submit|preventDefault={handleSubmit}>
    <div class="title">
      <label for="title">Title:</label>
      <input type="text" id="title" bind:value={title} required />
    </div>
    <div class="description">
      <label for="description">Description:</label>
      <textarea id="description" bind:value={description} required></textarea>
    </div>
    <div class="actions">
      <button type="submit" class="action-button">Add Item</button>
    </div>
  </form>
</div>

<style>
  .item {
    width: 465px;
    border: 1px solid #ccc;
    padding: 10px;
    margin: 10px;
    border-radius: 5px;
  }

  .title {
    margin-top: 20px;
    font-size: 1.2em;
    font-weight: bold;
    margin-bottom: 5px;
  }

  .description {
    margin-bottom: 10px;
  }

  .actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
  }

  .action-button {
    padding: 5px 10px;
    cursor: pointer;
    background-color: #4caf50;
    color: #fff;
    border: none;
    border-radius: 3px;
    margin: 5px;
  }

  input{
    border-radius: 30px;
  }

  textarea {
    margin-top: 20px;
    margin-left: 5px;
    border-radius: 5px;
  } 

</style>
