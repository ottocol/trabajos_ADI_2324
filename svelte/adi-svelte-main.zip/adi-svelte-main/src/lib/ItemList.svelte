<script>
  import { flip } from "svelte/animate";
  import { send, receive } from "../transition";
  import { items } from "../stores";
  import Item from "./Item.svelte";

  /**
   * @param {import("../stores").Item} _
   */
  export let predicate = (_) => true;
</script>

{#await items.fetchItemsTask}
  <h1>Loading...</h1>
{:then}
  {#each $items.filter(predicate) as item (item.id)}
    <div
      in:receive={{ key: item.id }}
      out:send={{ key: item.id }}
      animate:flip={{ duration: 200 }}
    >
      <Item itemid={item.id} />
    </div>
  {/each}
{:catch error}
  <h1>Error: {error}</h1>
{/await}
