<script>
  import { items } from "../stores";

  export let itemid;

  const item = items.getItem(itemid);
</script>

<div class="item">
  <div class="title {item.completed ? 'completed' : ''}">{item.title}</div>
  <div class="description">{item.description}</div>
  <div class="actions" >
    <button class="action-button" on:click={() => items.deleteItem(itemid)}>
      Delete
    </button>
    <button
      class="action-button"
      on:click={() => items.toggleCompleted(itemid)}
    >
      {item.completed ? "Mark as not done" : "Mark as done"}
    </button>
  </div>
</div>

<style>
  .completed {
    text-decoration: line-through;
  }

  .item {
    border: 1px solid #ccc;
    padding: 10px;
    margin: 10px;
    border-radius: 5px;
    height: 130px;
  }

  .title {
    font-size: 1.2em;
    font-weight: bold;
    margin-bottom: 5px;
  }

  .description {
    margin-bottom: 10px;
  }

  .actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
  }

  .action-button {
    padding: 5px 10px;
    cursor: pointer;
    background-color: #4caf50;
    color: #fff;
    border: none;
    border-radius: 3px;
    margin-top: 15px;
  }
</style>
