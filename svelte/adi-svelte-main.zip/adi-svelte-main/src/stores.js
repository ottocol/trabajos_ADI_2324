import { writable, get } from "svelte/store";

/**
 * @typedef {object} Item
 * @property {number} id
 * @property {string} title
 * @property {string} description
 * @property {boolean} completed
 */

/**
 * @returns {Promise<Array<Item>>}
 */
async function fetchItemsFromServer() {
  let id = 0;
  await new Promise((res, _) => setTimeout(res, 3000));
  return [
    {
      id: id++,
      title: "Tarea 1",
      description: "Primera tarea",
      completed: false,
    },
    {
      id: id++,
      title: "Tarea 2",
      description: "Segunda tarea",
      completed: true,
    },
    {
      id: id++,
      title: "Tarea 3",
      description: "Tercera tarea",
      completed: false,
    },
  ];
}

export const items = (() => {
  /**
   * @type {import("svelte/store").Writable<Array<Item>>}
   */
  const store = writable([]);
  const { subscribe, update, set } = store;

  let nextId = 0;
  let fetchItemsTask = fetchItemsFromServer().then((items) => {
    nextId = Math.max(...items.map((item) => item.id), -1) + 1;
    set(items);
  });

  /**
   * @param {number} id
   * @returns {Item | undefined}
   */
  function getItem(id) {
    return get(store).find((item) => item.id === id);
  }

  /**
   * @param {Object} param0
   * @param {string} param0.title
   * @param {string} param0.description
   * @param {boolean} [param0.completed=false]
   * @returns {Item}
   */
  function addItem({ title, description, completed = false }) {
    const item = {
      id: nextId++,
      title,
      description,
      completed,
    };
    update(($items) => [...$items, item]);
    return item;
  }

  /**
   * @param {number} id
   */
  function deleteItem(id) {
    update(($items) => $items.filter((item) => item.id !== id));
  }

  /**
   * @param {number} id
   */
  function toggleCompleted(id) {
    const item = getItem(id);
    update(($items) => [
      ...$items.filter((item) => item.id !== id),
      { ...item, completed: !item.completed },
    ]);
  }

  return {
    subscribe,
    getItem,
    addItem,
    deleteItem,
    toggleCompleted,

    get fetchItemsTask() {
      return fetchItemsTask;
    },
  };
})();
