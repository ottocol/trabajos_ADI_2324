Trabajo realizado por Javier Rodríguez Peréz, Alejandro Galán Peréz,
Carlos Robles Maranchon y Erik Avagyan.

Enlace al video: https://www.youtube.com/watch?v=vlGpULAZokc&ab_channel=AlejandroGal%C3%A1nP%C3%A9rez

Referencias:

- https://svelte.dev/docs/introduction
- https://learn.svelte.dev/tutorial/welcome-to-svelte