export interface Item {
    id: number;
    nombre: string;
    comprado: boolean;
}
