# Índice
### Instalación de Next.js
- Requisitos del Sistema
- Instalación Automática
- Instalación Manual

### Introducción a Next.js
### Características principales
  - Renderizado híbrido
  - Routing integrado
  - API Routes
  - Hot Module Replacement (HMR)
  - TypeScript integrado
  - Optimización automática

### Ventajas y Beneficios

### Arquitectura y Estructura de un Proyecto

### Estilos y CSS

### Ejemplos Prácticos y Casos de Uso

### Conclusiones

<br>
<br>

# Instalación de Next.js

## Requisitos del Sistema:
- Node.js 18.17 o versiones posteriores.
- Soporte para macOS, Windows (incluyendo WSL), y Linux.

## Instalación Automática:
Se sugiere iniciar una nueva aplicación Next.js utilizando `create-next-app`, el cual configura todo automáticamente. Para crear un proyecto, ejecuta el siguiente comando en tu terminal:

```bash
npx create-next-app@latest
```

Durante la instalación, se te pedirá proporcionar información como:

- **Nombre de tu proyecto:** Puedes ingresar el nombre que prefieras, por ejemplo, `mi-app`.
- **Uso de TypeScript:** Decide si deseas utilizar TypeScript.
- **Uso de ESLint:** Decide si deseas utilizar ESLint. Su objetivo principal es encontrar y señalar patrones problemáticos o código que pueda conducir a errores, ayudando así a mantener un código más consistente y legible en proyectos JavaScript.
- **Uso de Tailwind CSS:** Decide si deseas utilizar Tailwind CSS, un framework de estilos CSS que se centra en la construcción de interfaces de usuario de manera rápida y personalizable.
- **Directorio `src/`:** Puedes optar por utilizar un directorio `src/` para separar el código de tu aplicación de los archivos de configuración.
- **App Router:** Recomendado para su uso, pero opcional.
- **Personalización del alias de importación por defecto:**

Una vez que respondas estas preguntas, `create-next-app` creará una carpeta con el nombre que hayas proporcionado para tu proyecto e instalará las dependencias requeridas.


## Instalación Manual

Para crear manualmente una nueva aplicación Next.js, primero instala los paquetes necesarios en tu proyecto utilizando el siguiente comando:

```bash
npm install next@latest react@latest react-dom@latest
```
A continuación, abre tu archivo package.json y añade este script:
```json
{
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint"
  }
}
```
Estos scripts son esenciales para diferentes etapas del desarrollo de tu aplicación:

- **dev:** Ejecuta `next dev` para iniciar Next.js en modo de desarrollo.
- **build:** Utiliza `next build` para construir la aplicación para su uso en producción.
- **start:** Ejecuta `next start` para iniciar un servidor de producción de Next.js.
- **lint:** Utiliza `next lint` para configurar la herramienta de ESLint integrada en Next.js.
  
<br>
<br>

# Introducción a Next.js

Antes de proceder a explicar con más detalle todas las posibilidades y características de Next.js, vamos a explicar de qué se trata.

Next.js es un framework de React (librería open source para crear interfaces de usuario) que se creó con el objetivo de poder crear páginas webs tanto del lado del cliente como del servidor (full-stack). Como es lógico, su enfoque hacia la parte del cliente se basa en el uso de React, mientras que de la parte del servidor se encarga el propio Next.js, permitiendo diferentes formas de renderización y buscando la mayor optimización posible.

Este marco de desarrollo web se ha vuelto especialmente popular en los últimos años y a día de hoy es común encontrarse con equipos de desarrollo que trabajen con este en el ámbito web.

En los siguientes apartados profundizaremos acerca de sus puntos clave y las virtudes que estos poseen, además de ejemplificar estos con una DEMO desarrollada a partir de este framework.

<br>
<br>

# Características principales

## Renderizado híbrido

El renderizado híbrido en Next.js combina dos enfoques de renderizado: el renderizado del lado del servidor (SSR) y el renderizado del lado del cliente (CSR). Esta combinación permite obtener lo mejor de ambos mundos en términos de rendimiento y experiencia de usuario.
### Renderizado del lado del servidor (SSR):

Cuando un usuario solicita una página, el servidor genera HTML para esa página específica. Esto significa que el navegador recibe el HTML completo desde el servidor, lo que agiliza la carga inicial de la página.

### Renderizado del lado del cliente (CSR):

Una vez que la página inicial se ha cargado, las interacciones del usuario, como cambiar entre páginas o acciones dinámicas, se gestionan en el lado del cliente. Esto permite una experiencia más interactiva, ya que las actualizaciones de la página se realizan sin recargar la página.

Next.js facilita el renderizado híbrido al permitir que algunas páginas se pre-rendericen estáticamente durante el tiempo de compilación, lo que significa que el HTML se genera de antemano y se entrega al usuario de inmediato. Para otras páginas, se puede optar por el renderizado del lado del servidor, generando el HTML en tiempo real cuando se solicita la página. Esto se decide según las necesidades específicas de cada página o aplicación.

```javascript
import React from 'react';

const IndexPage = ({ serverTime }) => (

  <div>
    <h1>Página de inicio</h1>
    <p>El tiempo del servidor es: {serverTime}</p>
  </div>
);
export async function getServerSideProps() {
    // Esta función se ejecuta en el servidor
    const serverTime = new Date().toString();

    // Los datos obtenidos se pasan como props a la página
    return {
        props: {
            serverTime,
        },
    };
}
export default IndexPage;
```
En este ejemplo, getServerSideProps es una función específica de Next.js que se utiliza para obtener datos en el servidor antes de renderizar la página. Este enfoque garantiza que la hora del servidor se genere en cada solicitud de página. Si se usa getServerSideProps, la página se renderizará en el servidor; de lo contrario, se utilizará la pre-renderización estática para el renderizado del lado del cliente.

## Routing integrado
En Next.js el enrutamiento está integrado y simplificado.
Tenemos dos páginas: una página de inicio (index.js) y una página de contacto (contact.js).

```javascript
import React from 'react';
import Link from 'next/link';

const IndexPage = () => (
  <div>
    <h1>Página de inicio</h1>
    <p>Bienvenido a nuestra aplicación!</p>
    <Link href="/contact">
      <a>Ir a la página de contacto</a>
    </Link>
  </div>
);

export default IndexPage;

```
En este ejemplo, se utiliza el componente Link de Next.js para crear enlaces entre páginas. Cuando el usuario hace clic en el enlace, se dirige a la ruta especificada, en este caso, la página de contacto (/contact).

Next.js maneja automáticamente el enrutamiento, sin necesidad de configuraciones adicionales. Simplemente crea archivos dentro del directorio pages con los nombres correspondientes a las rutas que deseas establecer,

## API Routes

Next.js permite crear endpoints personalizados para manejar solicitudes HTTP. Esto facilita la construcción de APIs RESTful dentro de tu aplicación Next.js, separando la lógica del servidor del código del lado del cliente.

Para crear una API Route en Next.js, simplemente debemos crear archivos dentro del directorio `pages/api`. Cada archivo en este directorio define un endpoint que puede manejar diferentes tipos de solicitudes HTTP (GET, POST, PUT, DELETE, etc.).

Estos endpoints personalizados creados con API Routes pueden ser consumidos por tu aplicación front-end, permitiéndote desarrollar la lógica del servidor de forma integrada con tu aplicación Next.js.

En los siguientes apartados, veremos ejemplos prácticos de endpoints realizados con el framework Next.js.

## Hot Module Replacement (HMR)
El Hot Module Replacement (HMR) es una característica que permite actualizar partes específicas de una aplicación en tiempo real, sin recargar toda la página. En Next.js, HMR está integrado de manera predeterminada para agilizar el proceso de desarrollo.

Cuando estás trabajando en tu aplicación Next.js y realizas cambios en el código, la aplicación se actualiza automáticamente para reflejar esos cambios en el navegador sin necesidad de recargar la página por completo. 

 La integración del HMR en Next.js ayuda a los desarrolladores a mantener un flujo de trabajo ágil y eficiente, ya que proporciona una vista previa instantánea de los cambios realizados. Esto hace que el proceso de desarrollo sea más rápido y menos disruptivo, ya que no es necesario esperar a que se recargue toda la aplicación después de cada modificación.

 ## TypeScript integrado

Next.js ofrece una integración con TypeScript, lo que permite desarrollar aplicaciones con un alto nivel de tipado estático y detección de errores en tiempo de compilación. Esto proporciona una base sólida para construir aplicaciones web más robustas y mantenibles.

Para usar TypeScript en Next.js, puedes comenzar configurando tu proyecto para admitir archivos TypeScript. Si estás creando un nuevo proyecto, puedes usar la bandera `--typescript` al crear una nueva aplicación Next.js:

```bash
npx create-next-app nombre-de-tu-proyecto --typescript
```
## Optimización automática
La optimización automática se refiere a varias técnicas integradas que mejoran el rendimiento de la aplicación sin necesidad de configuraciones adicionales complejas. Estas optimizaciones se centran en mejorar la velocidad de carga y la eficiencia de la aplicación de forma automática.

**Code-splitting**: Next.js permite la división de código de manera automática mediante la técnica de code-splitting. Cuando utilizas import() o dynamic para importar componentes o módulos, Next.js identifica estos puntos y divide tu aplicación en "chunks" separados. Estos chunks se cargan de forma diferida, permitiendo que solo se cargue el código necesario cuando es necesario, reduciendo el tamaño del bundle inicial y mejorando el tiempo de carga.

**Prefetching**: Next.js incorpora estrategias de prefetching y precarga de recursos para mejorar la velocidad de navegación. Cuando utilizas el componente Link para navegar entre páginas, Next.js automáticamente pre-carga las páginas vinculadas en segundo plano. 

**Optimización de imágenes**: las imágenes se optimizan automáticamente para cargar de manera eficiente. Next.js genera múltiples versiones de la imagen en diferentes tamaños y formatos, lo que permite cargar la versión más adecuada según el dispositivo y el tamaño de la pantalla.

<br>
<br>

# Ventajas y Beneficios

Como ya se ha mencionado, este framework se ha convertido en uno de los más populares en los últimos tiempos, y esto se debe precisamente a los pros que trae consigo. A continuación se resumirán los principales beneficios que trae consigo su uso:

## Enrutamiento

Como ya se ha mencionado, Next.js trabaja con un enrutamiento automático que facilita su configuración y la vuelve más intuitiva.

## Renderización

Soporta tanto renderización en el lado del cliente como en el servidor (CSR y SSR respectivamente) permitiendo de esta manera la ya mencionada renderización híbrida que se trata de hacer uso de ambas en una misma aplicación para así utilizar de la manera más eficiente cada parte de nuestro programa. De esta manera podemos determinar a partir de nuestras necesidades y las del cliente qué prioridad dar a cada tipo de renderización y en qué parte de nuestra web hacerlo para así sacar la máxima efectividad al uso de React en Next.js.

## Mejoras en el SEO

Gracias al uso del pre-renderizado estático (SSG) que se encarga de generar las páginas en tiempo de compilación y a la posibilidad de guardarla en caché CDN (servidores proxy cercanos al usuario final) produce una mejora en el rendimiento de los motores de búsqueda (SEO).

## Facilidad en su uso

Cuenta con diferentes cualidades que permiten facilitar el desarrollo de aplicaciones, como es el ejemplo del enrutamiento automático, pero también otras como poder trabajar con recargas automáticas en la aplicación tras añadir código o la compatibilidad integrada con CSS-in-JS, por no hablar de que también cuenta con integración con TypeScript o APIs, que favorece al uso de ambas en la aplicación a diseñar.

## Estilo

Aunque ya se ha hablado de que tiene compatibilidad integrada con CSS-in-JS, cabe destacar que también da la posibilidad de estilizar la aplicación de otras maneras como utilizando CSS global, en módulo, CSS Tailwind o Sass.

## Optimizaciones

Incorpora una serie de optimizaciones diseñadas para mejorar la velocidad de la aplicación y cumplir así con las Core Web Vitals, que se tratan de tres métricas que determinan la percepción y satisfacción del usuario en una página web. Como ya hemos hablado anteriormente, las optimizaciones otorgadas además son automáticas.

## Amplia comunidad

Al haber ganado una notoria popularidad, cuenta con una gran y activa comunidad de desarrolladores, además de una amplia gama de bibliotecas y documentación que agilizan la resolución de dudas o problemas relacionados.

<br>
<br>

# Arquitectura y Estructura de un Proyecto

La arquitectura y estructura de un proyecto que utiliza Next.js en Node.js sigue un enfoque modular y organizado. Los siguientes son los componentes claves:

## Directorio `pages`

Es el componente central de la estructura de un proyecto Next.js. Cada archivo en este directorio representa una ruta de la aplicación. Por ejemplo, `pages/index.js` representa la ruta principal de la aplicación.

## Enrutamiento

Next.js utiliza un sistema de enrutamiento basado en convenciones. Los archivos en el directorio `pages` determinan las rutas de las páginas, y puedes anidar directorios para rutas más complejas. Por ejemplo, `pages/blog/post/[id].js` podría representar la ruta para mostrar un post específico.

## API Routes

El directorio `pages/api` se utiliza para definir rutas de la API. Los archivos en este directorio se manejan como endpoints de la API, facilitando la creación de servicios web dentro de la misma aplicación.

## Componentes React

Puedes organizar tus componentes React en directorios como `components` para una mejor modularidad y reutilización. Estos componentes pueden ser utilizados en varias páginas de la aplicación.

## Directorio `public`

Contiene archivos estáticos como imágenes, iconos o archivos de estilo que se servirán de manera estática. Por ejemplo, si hay una imagen en `public/images/logo.png`, podrías referenciarla en el código como `/images/logo.png`.

## Configuración y Personalización

Se puede agregar un archivo llamado `next.config.js` en la raíz del proyecto para configurar y personalizar aspectos de la construcción de la aplicación. Aquí podemos agregar plugins, configurar alias, entre otras cosas.

## Páginas de Error Personalizadas

Puedes crear páginas personalizadas para manejar errores específicos. Por ejemplo, `pages/404.js` se usará para mostrar una página personalizada cuando no se encuentre una ruta.

## Estilos y CSS

Next.js permite diferentes enfoques para manejar estilos. Puedes usar estilos globales, módulos de estilo, o integrar bibliotecas como Styled Components o Tailwind CSS según tus preferencias.

## Manejo de Datos y Funciones Estáticas

Utiliza funciones como `getStaticProps` y `getServerSideProps` para obtener y pasar datos a tus componentes antes de la renderización. Esto es crucial para el renderizado estático y del lado del servidor.

## Middleware y Configuración de Servidor

Si necesitas personalizar el servidor, puedes utilizar el archivo `server.js` o configurar middleware utilizando el método `express()` de Express, ya que Next.js se basa en Express.

En general, esta estructura modular y basada en convenciones facilita el desarrollo y la escalabilidad de las aplicaciones, permitiendo un mantenimiento más sencillo a medida que el proyecto crece.

<br>
<br>

# Estilos y CSS

A continuación, se explicará cómo se utilizan cada una de las diferentes opciones que permite Next.js para trabajar con estilos y CSS.

## Módulos CSS

Para crear archivos que soporten módulos de CSS se utiliza la extensión `.module.css`. Estos módulos pueden ser importados en cualquier archivo dentro de `/App` y son perfectos para trabajar con estilos a nivel de componente debido a que tienen un nombre de clase único que permite usar el mismo nombre de clase en diferentes archivos sin generar colisiones.

```css
/* Este CSS solo cambiará aquello en el módulo que lo importa, Button.js */
.button {
  background-color: #3498db;
  color: #ffffff;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
```
```jsx
import styles from './Button.module.css';

const Button = () => {
  return (
    <button className={styles.button}>
      Click me
    </button>
  );
};
```
Además de esto, se puede seguir utilizando CSS global como se haría en cualquier otro proyecto, además de estilos importados como Bootstrap. Cabe destacar que los cambios en el CSS se realizan de forma automática durante sus modificaciones si se está testeando la aplicación en local.

## Tailwind CSS

Para utilizar este framework de CSS, tendremos que instalarlo:

```bash
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```
Después, en nuestro proyecto, especificamos qué archivos se valdrán de Tailwind CSS. Esto se hace en el archivo `tailwind.config.js`:
```js
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/Button.js{js,ts,jsx,tsx,mdx}', // Especificamos que solo queremos usarlo en el componente Button
    // O si estás utilizando el directorio `src`:
    './src/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```
Una vez especificado esto, podemos ir a globals.css y especificar qué funcionalidades queremos que traiga Tailwind a nuestra aplicación, como por ejemplo:

 ```css
@tailwind base; /* Todos los estilos básicos de Tailwind y aquellos registrados con plugins */
@tailwind components; /* Todos aquellos componentes de clase de Tailwind y los registrados con plugins */
@tailwind utilities; /* Todas aquellas clases de utilidad de Tailwind y las registradas con plugins */
```

Ahora bastará con importar el globals.css al lugar donde queremos utilizar los nuevos estilos y empezar a utilizar sus clases:
```js
// Button.js con Tailwind
import './globals.css ';

const Button = () => {
    return (
        <button className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700">
        Click me
        </button>
    );
};
```
## CSS-in-JS

Para la configuración previa de CSS-in-JS, seguiremos tres pasos:

1. Creamos un nuevo archivo `app/registry.tsx` para juntar todas las reglas del CSS en un renderizado. Usaremos para ello `styled-jsx` y la directiva `useServerInsertedHTML`.

2. Utilizaremos el proyecto anterior para insertar `styled-jsx` en nuestro layout de esta forma:

```js
import StyledJsxRegistry from './registry';

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html>
      <body>
        <StyledJsxRegistry>{children}</StyledJsxRegistry>
      </body>
    </html>
  );
}
```
Cabe destacar que este proceso es similar para otraas herramientas creadas por la comunidad con este fin, como es el caso de Styled Components o Emotion, aunque cada una puede tener pequeñas variaciones.

## Sass

Lo primero que debemos hacer es instalar Sass:

```bash
npm install --save-dev sass
```
Si queremos cambiar alguna de sus configuraciones, podemos usar `sassOptions` ubicado en `next.config.js`:
```js
const path = require('path');
module.exports = {
  sassOptions: {
    includePaths: [path.join(__dirname, 'styles')],
  },
};
```
Una vez hecho esto, podemos usar Sass tanto por medio de módulos de CSS con la extensión `.module.scss` como con `.module.sass`. Un ejemplo de la primera de estas sería:
```scss
// En app/variables.module.scss
$primary-color: #64ff00;
:export {
  primaryColor: $primary-color;
}
```
Y en la página `pages/index.js`, podemos utilizar las variables Sass:

```js
import variables from './variables.module.scss';

const HomePage = () => {
  return (
    <div>
      <h1 style={{ color: variables.primaryColor }}>My Next.js App</h1>
      <Button onClick={() => console.log('Button clicked')}>Click me</Button>
    </div>
  );
};

export default HomePage;
```
<br>
<br>

# Ejemplos Prácticos y Casos de Uso
En este apartado vamos a ver cómo se definirían diferentes endpoints de una api que podría usar el proyecto. Primero vamos a crear una lista en el directorio raíz para que pueda ser utilizada en las llamadas de la api:
```js
// itemsData.js

const items = [
  { id: 1, name: 'Item 1' },
  { id: 2, name: 'Item 2' },
  { id: 3, name: 'Item 3' },
];

export default items;
```

Ahora creamos las carpetas /pages/api y dentro creamos un archivo items.js donde definiremos endpoint de tipo GET:

```js
// pages/api/items.js

import items from '../../itemsData';

export default function handler(req, res) {
  if (req.method === 'GET') {
    // Si la solicitud es un método GET, devuelve la lista de items.
    res.status(200).json(items);
  } else {
    // Si el método no es GET, devuelve un error 405 (Método no permitido).
    res.status(405).end();
  }
}
```
## Funcionamiento

### Export default function handler(req, res):
Next.js espera que exportes una función por defecto llamada handler en tus archivos API. Esta función toma dos parámetros: `req` (la solicitud HTTP) y `res` (la respuesta HTTP).
Esta función es el controlador principal que maneja todas las solicitudes entrantes en el endpoint.

### Manejo del método GET:

El código verifica si la solicitud es un método GET `req.method === 'GET'`. Si es así, devuelve la lista de items con un código de estado 200 en formato JSON `res.status(200).json(items)`.
Si el método no es GET, devuelve un error 405 (Método no permitido) con `res.status(405).end()`.

La exportación del handler y su estructura es una convención que Next.js utiliza para organizar el código en las API routes. Cuando visitas una URL correspondiente a tu API route (`/api/items` en este caso), Next.js ejecuta automáticamente esta función handler y maneja la lógica según el método de solicitud HTTP.

<br>
<br>

# Conclusiones
En definitiva, tras la investigación, el previo análisis y el uso de Next.js podemos ver de manera clara cuáles son los motivos por los que este framework ha tenido una gran relevancia en el desarrollo de aplicaciones web.


Este no solo ofrece grandes facilidades y comodidad a la hora de realizar muchas de las funciones necesarias en una web, como la optimización automática o su enrutamiento, también automático, si no que también permite un gran abanico de posibilidades a la hora de elegir características importantes de nuestra web, como puede ser el renderizado (CSR, SSR o híbrida) o el uso de estilos (module CSS, CSS-in-JS, Sass, Tailwind CSS).


Si a todo esto le sumamos una gran y activa comunidad así como constantes actualizaciones que lo mantienen al día en innovaciones sobre la creación de webs, no cabe la menor duda acerca del por qué debe ser una de las principales opciones a tener en cuenta a la hora de desarrollar cualquier tipo de aplicación web full-stack.

