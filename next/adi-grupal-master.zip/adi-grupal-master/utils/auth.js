// utils/auth.js
import { v4 as uuidv4 } from 'uuid';

let users = [{ id: 1, username: 'userPrueba', password: '1234'}]

export const registerUser = (username, password) => {
  const hashedPassword = `hashed_${password}`;

  const newUser = {
    id: uuidv4(),
    username,
    password: hashedPassword,
  };

  users.push(newUser);

  return newUser;
};

export const loginUser = (username, password) => {
    console.log("Usuarios antes de login", users);
  const user = users.find((u) => u.username === username && u.password === `hashed_${password}`);

  return user ? generateFakeToken() : null;
};

export const isAuthenticated = (token) => {
  // En una implementación real, verificarías el token JWT.
  return token === 'validToken';
};

const generateFakeToken = () => {
  return 'validToken'; // En una implementación real, generaría un token JWT.
};

export const getUserByName = (username) => {
  console.log("Nombre de usuario buscado:", username);
  console.log("Usuarios en el sistema:", users);
  const user = users.find((u) => u.username === username);
  console.log("Usuario en getUserByName:" , user);
  if (user) {
    const { username, password } = user;
    return { username, password: password.replace(/^hashed_/, '') };
  }

  return null;
};

export const updateUserPassword = (username, newPassword) => {
  const userIndex = users.findIndex((user) => user.username === username);

  if (userIndex !== -1) {
    users[userIndex].password = `hashed_${newPassword}`;
    return { success: true, message: 'Contraseña actualizada con éxito' };
  } else {
    return { success: false, message: 'Usuario no encontrado' };
  }
};