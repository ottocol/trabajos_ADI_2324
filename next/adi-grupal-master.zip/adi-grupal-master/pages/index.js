import Header from '../components/Header';
import { useEffect, useState } from 'react';
import fetch from 'isomorphic-unfetch';

const Home = ({ posts: initialPosts }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [posts, setPosts] = useState(initialPosts);

  useEffect(() => {
    const checkAuthentication = () => {
      const isAuthenticated = localStorage.getItem('isLoggedIn') === 'true';
      setIsLoggedIn(isAuthenticated);
    };

    checkAuthentication();
  }, []);

  const handleLogout = () => {
    setIsLoggedIn(false);
    localStorage.removeItem('isLoggedIn');
  };

  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostContent, setNewPostContent] = useState('');

  const handleTitleChange = (event) => {
    setNewPostTitle(event.target.value);
  };

  const handleContentChange = (event) => {
    setNewPostContent(event.target.value);
  };

  const handleCreatePost = async () => {
    try {
      const res = await fetch('http://localhost:3000/api/posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: newPostTitle,
          content: newPostContent,
        }),
      });

      if (res.status === 201) {
        // Actualizar la lista de posts después de crear uno nuevo
        const newPost = await res.json();
        const updatedPosts = [...posts, newPost];

        // Actualizar el estado con las nuevas publicaciones
        setPosts(updatedPosts);

        // Limpiar los campos de entrada
        setNewPostTitle('');
        setNewPostContent('');
      } else {
        // Manejar casos de error
        console.error('Error al crear el post');
      }
    } catch (error) {
      console.error('Error de red:', error);
    }
  };

  const [editingPostId, setEditingPostId] = useState(null);
  const [editingPostTitle, setEditingPostTitle] = useState('');
  const [editingPostContent, setEditingPostContent] = useState('');  

  const handleEditPost = (postId, postTitle, postContent) => {
    setEditingPostId(postId);
    setEditingPostTitle(postTitle);
    setEditingPostContent(postContent);
  };  

  const handleUpdatePost = async () => {
    try {
      const res = await fetch(`http://localhost:3000/api/posts`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: editingPostId,
          title: editingPostTitle,
          content: editingPostContent,
        }),
      });
  
      if (res.status === 200) {
        // Actualizar la lista de posts después de actualizar uno existente
        const updatedPosts = posts.map((post) =>
          post.id === editingPostId ? { ...post, title: editingPostTitle, content: editingPostContent } : post
        );
  
        // Actualizar el estado con las nuevas publicaciones y salir del modo de edición
        setPosts(updatedPosts);
        setEditingPostId(null);
      } else {
        console.error('Error al actualizar el post');
      }
    } catch (error) {
      console.error('Error de red:', error);
    }
  };
  const handleDeletePost = async (postId) => {
    try {
      const res = await fetch(`http://localhost:3000/api/posts?id=${postId}`, {
        method: 'DELETE',
      });
  
      if (res.status === 200) {
        // Eliminar el post de la lista después de la eliminación exitosa
        const updatedPosts = posts.filter((post) => post.id !== postId);
        setPosts(updatedPosts);
      } else {
        console.error('Error al eliminar el post');
      }
    } catch (error) {
      console.error('Error de red:', error);
    }
  };  

  return (
    <div>
      <Header />
      <main className="container mx-auto p-4">
        {isLoggedIn ? (
          <div>
            <h2 className="text-2xl font-bold mb-4">Últimas publicaciones</h2>
            <ul>
            {posts.map((post) => (
              <li key={post.id} className="post mb-4">
              {editingPostId === post.id ? (
                  <div className="mt-4 text-center">
                    <h2 className="text-2xl font-bold mb-4 mx-auto">Editar post</h2>
                    <form>
                      <div className="mb-4">
                        <label htmlFor="editTitle" className="block text-sm font-medium text-white">
                          Nuevo título:
                        </label>
                        <input
                          type="text"
                          id="editTitle"
                          name="editTitle"
                          value={editingPostTitle}
                          onChange={(e) => setEditingPostTitle(e.target.value)}
                          className="mt-1 p-2 border border-gray-300 rounded-md w-full text-black"
                        />
                      </div>
                      <div className="mb-4">
                        <label htmlFor="editContent" className="block text-sm font-medium text-white">
                          Nuevo contenido:
                        </label>
                        <textarea
                          id="editContent"
                          name="editContent"
                          value={editingPostContent}
                          onChange={(e) => setEditingPostContent(e.target.value)}
                          className="mt-1 p-2 border border-gray-300 rounded-md w-full text-black"
                        ></textarea>
                      </div>
                      <button
                        type="button"
                        onClick={handleUpdatePost}
                        className="bg-green-500 text-white px-4 py-2 rounded-md transition duration-300 hover:bg-green-700">
                          Actualizar Post
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingPostId(null)}
                        className="bg-gray-500 text-white px-4 py-2 rounded-md ml-2">
                          Cancelar
                      </button>
                    </form>
                  </div>
                ) : (
                  <div>
                    <h3 className="text-xl font-bold">{post.title}</h3>
                    <p>{post.content}</p>
                    <button
                      className="bg-red-500 text-white px-2 py-1 rounded-md mt-2"
                      onClick={() => handleDeletePost(post.id)}>
                      Eliminar
                    </button>
                    <button
                      className="bg-yellow-500 text-black px-2 py-1 rounded-md mt-2"
                      onClick={() => handleEditPost(post.id, post.title, post.content)}>
                      Editar
                    </button>
                  </div>
                )}
              </li>
            ))}
          </ul>
            <div className="mt-4 text-center">
              <h2 className="text-2xl font-bold mb-4 mx-auto">Crear nuevo post</h2>
              <form>
              <div className="mb-4">
                <label htmlFor="title" className="block text-sm font-medium text-white">
                  Título:
                </label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  value={newPostTitle}
                  onChange={handleTitleChange}
                  className="mt-1 p-2 border border-gray-300 rounded-md w-full text-black"
                />
              </div>
              <div className="mb-4">
                <label htmlFor="content" className="block text-sm font-medium text-white">
                  Contenido:
                </label>
                <textarea
                  id="content"
                  name="content"
                  value={newPostContent}
                  onChange={handleContentChange}
                  className="mt-1 p-2 border border-gray-300 rounded-md w-full text-black"
                ></textarea>
              </div>
                <button
                  type="button"
                  onClick={handleCreatePost}
                  className="bg-blue-500 text-white px-4 py-2 rounded-md transition duration-300 hover:bg-blue-700">
                    Crear Post
                </button>
              </form>
            </div>
          </div>
        ) : (
          <p>Debes iniciar sesión para ver las publicaciones.</p>
        )}
      </main>
    </div>
  );
};

export async function getServerSideProps() {
  const res = await fetch('http://localhost:3000/api/posts');
  const posts = await res.json();

  return {
    props: {
      posts,
    },
  };
}

export default Home;
