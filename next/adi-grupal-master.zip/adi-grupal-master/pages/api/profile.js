
import { updateUserPassword, getUserByName } from '../../utils/auth';

export default function handler(req, res) {
    if (req.method === 'PATCH') {
        const { username, currentPassword, newPassword } = req.body;
    
        // Verificar si el usuario existe
        console.log('Prexisting User:', username);
        const existingUser = getUserByName(username);
        console.log('Existing User:', existingUser);
        if (existingUser === null) {
          return res.status(404).json({ error: 'Usuario no encontrado' });
        }
    
        console.log('Prexisting passw:', currentPassword);
        // Verificar si la contraseña actual coincide
        if (existingUser.password !== currentPassword) {
          return res.status(401).json({ error: 'Contraseña actual incorrecta' });
        }
        
        // Actualizar la contraseña del usuario
        updateUserPassword(username, newPassword);
    
        return res.status(200).json({ success: true, message: 'Contraseña actualizada' });
      } else {
        res.status(405).json({ message: 'Metodo no permitido' });
    }

    return res.status(404).json({ error: 'Endpoint not found' });
}