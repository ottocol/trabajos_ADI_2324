/// pages/api/register.js
import { registerUser } from '../../utils/auth';

export default function handler(req, res) {
  if (req.method === 'POST') {
    const { username, password } = req.body;

    const newUser = registerUser(username, password);

    res.status(201).json(newUser);
  } else {
    res.status(405).json({ message: 'Method Not Allowed' });
  }
}