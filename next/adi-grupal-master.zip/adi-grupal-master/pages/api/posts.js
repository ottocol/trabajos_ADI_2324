let posts = [
  { id: 1, title: 'Cómo Maximizar tu Productividad: Estrategias Prácticas para el Éxito Diario', content: 'En el ajetreado ritmo de la vida actual, maximizar la productividad se ha convertido en una habilidad crucial para alcanzar el éxito diario. En nuestra publicación sobre "Cómo Maximizar tu Productividad": Estrategias Prácticas para el Éxito Diario, exploramos un conjunto de estrategias probadas y prácticas diseñadas para ayudarte a sobresalir en tus tareas cotidianas. Desde la efectiva regla de los 2 minutos hasta técnicas de planificación inteligente, priorización estratégica y gestión de interrupciones, esta guía te proporciona herramientas esenciales para mejorar tu rendimiento diario. Descubrirás cómo equilibrar la eficiencia con el autocuidado, incorporando descansos y recuperación, junto con la automatización y delegación, para trabajar de manera más inteligente y lograr un éxito sostenible a largo plazo. ¡Atrévete a implementar estas prácticas en tu rutina y transforma tu enfoque hacia una productividad más significativa y satisfactoria' },
  { id: 2, title: 'Cómo Cultivar Hábitos de Lectura: Consejos para Fomentar el Placer de la Lectura', content: 'En un mundo digitalizado y acelerado, cultivar hábitos de lectura puede parecer un desafío, pero es una práctica que puede enriquecer enormemente nuestras vidas. En nuestra publicación sobre "Cómo Cultivar Hábitos de Lectura: Consejos para Fomentar el Placer de la Lectura", exploraremos estrategias prácticas para integrar la lectura en tu rutina diaria y redescubrir el placer de sumergirse en un buen libro. Desde la creación de un espacio acogedor de lectura hasta la diversificación de géneros y la gestión del tiempo, descubrirás cómo hacer que la lectura sea una parte fundamental de tu vida, disfrutando no solo de sus beneficios educativos, sino también de la relajación y la escapada que ofrece. ¡Acompáñanos en este viaje para redescubrir el placer de perderse en las páginas de un buen libro y cultivar hábitos de lectura que perduren a lo largo del tiempo!' },
  { id: 3, title: 'La Importancia de la Resiliencia: Cómo Desarrollar una Mentalidad Resistente', content: 'Enfrentar desafíos y superar adversidades es parte inevitable de la vida. En nuestra exploración sobre "La Importancia de la Resiliencia: Cómo Desarrollar una Mentalidad Resistente", nos sumergiremos en el concepto de resiliencia como una habilidad clave para afrontar las incertidumbres y crecer ante la adversidad. Analizaremos estrategias prácticas para fortalecer tu resiliencia, desde la gestión del estrés hasta la construcción de relaciones sólidas y el cambio de perspectiva. Descubrirás cómo convertir los obstáculos en oportunidades de crecimiento y aprender a recuperarte con fuerza de los golpes de la vida. Únete a nosotros mientras exploramos cómo desarrollar una mentalidad resistente que te permita no solo sobrevivir a los desafíos, sino prosperar y florecer a pesar de ellos.' },
];

export default function handler(req, res) {
  if (req.method === 'GET') {
    // Endpoint para obtener todos los posts
    return res.status(200).json(posts);
  }

  if (req.method === 'POST') {
    // Endpoint para crear un nuevo post
    const { title, content } = req.body;
    if (!title || !content) {
      return res.status(400).json({ error: 'Title and content are required' });
    }
  
    const newPost = { id: posts.length + 1, title, content };
    posts = [...posts, newPost];
  
    return res.status(201).json(newPost);
  }  

  if (req.method === 'DELETE') {
    // Endpoint para eliminar un post
    const { id } = req.query;
    if (!id) {
      return res.status(400).json({ error: 'Post ID is required for deletion' });
    }

    const deletedPostIndex = posts.findIndex((post) => post.id == id);
    if (deletedPostIndex === -1) {
      return res.status(404).json({ error: 'Post not found' });
    }

    const deletedPost = posts[deletedPostIndex];
    posts = posts.filter((post) => post.id != id);

    return res.status(200).json(deletedPost);
  }

  if (req.method === 'PUT') {
    // Endpoint para modificar un post
    const { id, title, content } = req.body;
    const postId = id;
    if (!title || !content || !id) {
      return res.status(400).json({ error: 'Title, content and id are required' });
    }

    const postMod = posts.findIndex(post => post.id === postId);
    if(postMod !== -1){
      posts[postMod] = { ...posts[postMod], title, content };
      res.json({ success: true, message: 'Post actualizado con éxito' });
    }
    else{
      return res.status(404).json({ error: 'Post not found' });
    }
    return res.status(200).json(postMod);
  }

  return res.status(404).json({ error: 'Endpoint not found' });
}
