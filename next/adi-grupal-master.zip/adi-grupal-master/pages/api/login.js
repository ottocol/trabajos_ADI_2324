// pages/api/login.js
import { loginUser } from '../../utils/auth';

export default function handler(req, res) {
  if (req.method === 'POST') {
    const { username, password } = req.body;

    const token = loginUser(username, password);

    if (token) {
      res.status(200).json({ token });
    } else {
      res.status(401).json({ message: 'Unauthorized' });
    }
  } else {
    res.status(405).json({ message: 'Method Not Allowed' });
  }
}