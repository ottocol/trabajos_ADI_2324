// pages/login.js
import Header from '../components/Header';
import LoginForm from '../components/LoginForm';

const Login = () => {
  return (
    <div>
      <Header />
      <main className="container mx-auto p-4">
        <LoginForm />
      </main>
    </div>
  );
};

export default Login;