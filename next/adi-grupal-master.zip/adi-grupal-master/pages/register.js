// pages/register.js
import Header from '../components/Header';
import RegisterForm from '../components/RegisterForm';

const Register = () => {
  return (
    <div>
      <Header />
      <main className="container mx-auto p-4">
        <RegisterForm />
      </main>
    </div>
  );
};

export default Register;