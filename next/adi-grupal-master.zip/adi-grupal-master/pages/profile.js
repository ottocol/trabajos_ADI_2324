// pages/login.js
import { useState } from 'react';
import Header from '../components/Header';
import EditProfileForm from '../components/EditProfileForm';

const Profile = () => {
  const [showChangePasswordForm, setShowChangePasswordForm] = useState(false);

  const handleShowChangePasswordForm = () => {
    setShowChangePasswordForm(true);
  };

  const handleCloseChangePasswordForm = () => {
    setShowChangePasswordForm(false);
  };

  return (
    <div>
      <Header />
      <main className="container mx-auto p-4">
        <h1>Bienvenido!</h1>

        <button onClick={handleShowChangePasswordForm} className="bg-blue-500 text-white px-4 py-2 rounded-md mt-4">
          Cambiar Contraseña
        </button>

        {showChangePasswordForm && (
          <div className="mt-4">
            <EditProfileForm />
          </div>
        )}
      </main>
    </div>
  );
};

export default Profile;
