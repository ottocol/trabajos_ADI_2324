// components/Header.js
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router'; 

const Header = () => {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const router = useRouter();
    useEffect(() => {
      // Verificar si el usuario está autenticado al cargar la página
      const checkAuthentication = () => {
        const isAuthenticated = localStorage.getItem('isLoggedIn') === 'true';
        setIsLoggedIn(isAuthenticated);
      };

      checkAuthentication();
    }, []);
      const handleLogout = () => {
        localStorage.setItem('isLoggedIn', 'false');
    
        setTimeout(() => {
            window.location.reload();
        }, 1000);
        router.push('/login');
    };
  
  return (
    <header className="bg-gray-800 p-4 text-white">
      <nav className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Mi Blog</h1>
        <div className="flex items-center space-x-4">
        <Link href="/">
            Home
          </Link>
          {isLoggedIn ? (
            <>
            <Link href="/profile">
            Mi perfil
            </Link>
            <button
              onClick={handleLogout}
              className="bg-gray-600 hover:bg-gray-700 px-4 py-2 rounded"
            >
              Cerrar Sesión
            </button>
            </>

          ) : (
            <>
              <Link href="/login">
                Iniciar Sesión
              </Link>
              <Link href="/register">
                Registrarse
              </Link>
            </>
          )}
        </div>
      </nav>
    </header>
  );
};

export default Header;