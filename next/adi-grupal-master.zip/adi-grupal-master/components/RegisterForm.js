// components/RegisterForm.js
import { useState } from 'react';
import { useRouter } from 'next/router';

const RegisterForm = () => {
    const router = useRouter();
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (res.status === 201) {
        router.push('/login');
        // Registro exitoso, puedes redirigir al usuario a la página de inicio de sesión o hacer otra acción.
        console.log('Registro exitoso!');
      } else {
        // Manejar errores de registro
        console.error('Error en el registro:', res.statusText);
      }
    } catch (error) {
      console.error('Error en el registro:', error.message);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen">
  <form onSubmit={handleSubmit} className="bg-gray-800 p-8 rounded-md shadow-md w-96">
    <h2 className="text-white text-2xl font-bold mb-4">Registro</h2>
    <div className="mb-4">
      <label htmlFor="username" className="text-white">
        Usuario:
      </label>
      <input
        type="text"
        id="username"
        name="username"
        value={formData.username}
        onChange={handleInputChange}
        required
        className="w-full p-2 mt-2 rounded-md bg-gray-700 text-white focus:outline-none focus:ring focus:border-blue-300"
      />
    </div>
    <div className="mb-4">
      <label htmlFor="password" className="text-white">
        Contraseña:
      </label>
      <input
        type="password"
        id="password"
        name="password"
        value={formData.password}
        onChange={handleInputChange}
        required
        className="w-full p-2 mt-2 rounded-md bg-gray-700 text-white focus:outline-none focus:ring focus:border-blue-300"
      />
    </div>
    <button
      type="submit"
      className="w-full bg-green-500 hover:bg-green-600 text-white p-2 rounded-md transition duration-300 ease-in-out"
    >
      Registrarse
    </button>
  </form>
</div>
  );
};

export default RegisterForm;