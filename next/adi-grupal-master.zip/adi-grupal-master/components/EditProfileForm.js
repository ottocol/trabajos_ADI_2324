// components/EditProfileForm.js
import { useState } from 'react';
import { useRouter } from 'next/router';

const EditProfileForm = ({ onSave }) => {
  const [formData, setFormData] = useState({
    username: '',
    currentPassword: '',
    newPassword: '',
  });

  const [successMessage, setSuccessMessage] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/profile', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (res.status === 200) {
        console.log('Cambio de contraseña exitoso!');
        setSuccessMessage('Cambio de contraseña exitoso!');
        setErrorMessage(null);
      } else {
        console.error('Error en el cambio de contraseña:', res.statusText);
        setErrorMessage(`Error en el cambio de contraseña: ${res.statusText}`);
        setSuccessMessage(null);
      }
    } catch (error) {
      console.error('Error en el cambio de contraseña:', error);
      res.status(500).json({ success: false, message: 'Error interno del servidor' });
      setErrorMessage(`Error en el cambio de contraseña: ${error.message}`);
      setSuccessMessage(null);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-gray-800 p-8 rounded-md shadow-md w-96">
      <h2 className="text-white text-2xl font-bold mb-4">Cambiar contraseña</h2>
      {successMessage && <p className="text-green-500 mb-4">{successMessage}</p>}
      {errorMessage && <p className="text-red-500 mb-4">{errorMessage}</p>}
      <div className="mb-4">
        <label htmlFor="username" className="text-white">
          Nombre de Usuario:
        </label>
        <input
          type="text"
          id="username"
          name="username"
          value={formData.username}
          onChange={handleInputChange}
          required
          className="w-full p-2 mt-2 rounded-md bg-gray-700 text-white"
        />
      </div>
      <div className="mb-4">
        <label htmlFor="currentPassword" className="text-white">
          Contraseña Actual:
        </label>
        <input
          type="password"
          id="currentPassword"
          name="currentPassword"
          value={formData.currentPassword}
          onChange={handleInputChange}
          required
          className="w-full p-2 mt-2 rounded-md bg-gray-700 text-white"
        />
      </div>
      <div className="mb-4">
        <label htmlFor="newPassword" className="text-white">
          Nueva Contraseña:
        </label>
        <input
          type="password"
          id="newPassword"
          name="newPassword"
          value={formData.newPassword}
          onChange={handleInputChange}
          required
          className="w-full p-2 mt-2 rounded-md bg-gray-700 text-white"
        />
      </div>
      <button
        type="submit"
        className="w-full bg-blue-500 hover:bg-blue-600 text-white p-2 rounded-md transition duration-300 ease-in-out"
      >
        Guardar Cambios
      </button>
    </form>
  );
};

export default EditProfileForm;
