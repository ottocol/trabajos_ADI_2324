// components/LoginForm.js
import { useState } from 'react';
import { useRouter } from 'next/router';

const LoginForm = ({ onLoginSuccess }) => {
    const router = useRouter();
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (res.status === 200) {
        localStorage.setItem('isLoggedIn', 'true');
        router.push('/');
        // Inicio de sesión exitoso, puedes realizar acciones adicionales, como redirigir al usuario.
        console.log('Inicio de sesión exitoso!');
        // Simulamos almacenamiento del token de sesión (en la realidad, usaríamos localStorage o cookies).
        localStorage.setItem('fakeToken', (await res.json()).token);
      } else {
        // Manejar errores de inicio de sesión
        console.error('Error en el inicio de sesión:', res.statusText);
      }
    } catch (error) {
      console.error('Error en el inicio de sesión:', error.message);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen">
  <form
    onSubmit={handleSubmit}
    className="bg-gray-800 p-8 rounded-md shadow-md w-96"
  >
    <h2 className="text-white text-2xl font-bold mb-4">Inicio de Sesión</h2>
    <div className="mb-4">
      <label htmlFor="username" className="text-white">
        Usuario:
      </label>
      <input
        type="text"
        id="username"
        name="username"
        value={formData.username}
        onChange={handleInputChange}
        required
        className="w-full p-2 mt-2 rounded-md bg-gray-700 text-white"
      />
    </div>
    <div className="mb-4">
      <label htmlFor="password" className="text-white">
        Contraseña:
      </label>
      <input
        type="password"
        id="password"
        name="password"
        value={formData.password}
        onChange={handleInputChange}
        required
        className="w-full p-2 mt-2 rounded-md bg-gray-700 text-white"
      />
    </div>
    <button
      type="submit"
      className="w-full bg-blue-500 hover:bg-blue-600 text-white p-2 rounded-md transition duration-300 ease-in-out"
    >
      Iniciar Sesión
    </button>
  </form>
</div>
  );
};

export default LoginForm;